import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { take } from 'rxjs/operators'

import { BooksService } from 'src/app/services/books.service';

@Component({
    selector: 'app-books-form',
    templateUrl: './books-form.component.html',
    styleUrls: []
  })

  export class BooksFormComponent implements OnInit {
    book = {};
    id;

    constructor(
    private route: ActivatedRoute,
    private router: Router,
    private booksService: BooksService
    ) {
        this.id = this.route.snapshot.paramMap.get('id');
        console.log("Book ID", this.id);

           // Important line of code to get single product from firebase
    if(this.id) this.booksService.get(this.id).valueChanges().
    pipe(take(1)).subscribe(p => this.book = p);

    }

    save(book) {
        console.log(book);
        if(this.id) this.booksService.update(this.id, book)
        else 
        this.booksService.create(book);    
        this.router.navigate(['/admin/books']);        
      }

    ngOnInit() { } 

  }