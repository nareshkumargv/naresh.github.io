import { Component, OnInit, Input } from '@angular/core';
//import { Product } from 'src/app/model/product';
import { ShoppingCartService } from 'src/app/services/shopping-cart.service';

import { Books } from 'src/app/model/books';

@Component({
  selector: 'product-quantity',
  templateUrl: './product-quantity.component.html',
  styleUrls: ['./product-quantity.component.css']
})
export class ProductQuantityComponent implements OnInit {
 // @Input('books') books: Books;
  @Input('product') product: Books;
  @Input('shopping-cart') shoppingCart;

  constructor(private cartService: ShoppingCartService) { }

  addToCart() {
    this.cartService.addToCart(this.product); 
  }

  removeFromCart() {
    this.cartService.removeFromCart(this.product); 
  }

  ngOnInit() {
  }

}
