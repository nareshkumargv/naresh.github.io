import { Component, ViewEncapsulation, OnInit } from '@angular/core';
import { AuthService } from "../../services/auth.service";
import { Router } from '@angular/router';
import { UserService } from '../../services/user.service';
import { trigger, transition, group, query, style, animate } from '@angular/animations';

@Component({
  selector: 'app-site-layout',
  templateUrl: './site-layout.component.html',
  styleUrls: ['./site-layout.component.css'],
  //encapsulation: ViewEncapsulation.Native
  //encapsulation: ViewEncapsulation.ShadowDom
  //encapsulation: ViewEncapsulation.Emulated
  encapsulation: ViewEncapsulation.None
})
export class SiteLayoutComponent implements OnInit {

    constructor (
        private userService: UserService, 
        private auth: AuthService, 
        router: Router) {
        auth.user$.subscribe(user => {
          if(!user) return;
          
            userService.save(user);
    
            let returnUrl = localStorage.getItem('returnUrl');
    
            if(!returnUrl) return;
    
            localStorage.removeItem('returnUrl')
            router.navigateByUrl(returnUrl);    
        })
    };

    getDepth(outlet) {
        return outlet.activatedRouteData['depth'];
      }

  ngOnInit() {
  }

}
