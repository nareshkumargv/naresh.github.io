import { Component, OnInit, OnDestroy, ViewChild } from '@angular/core';
import { ActivatedRoute} from '@angular/router';
import { Subscription } from 'rxjs';

import { MatTableDataSource } from '@angular/material/table';
import { MatDialogService } from 'src/app/services/mat-dialog.service';

import { Category } from 'src/app/model/categories';
import { CategoriesService } from 'src/app/services/categories.service';

@Component({
    selector: 'app-categories',
    templateUrl: './admin-categories.component.html',
    styleUrls: []
  })
  export class AdminCategoriesComponent implements  OnInit {
    categories: Category[];
    subscription: Subscription;
    items: Category[] = [];
    itemCount: number;
    dude: any;
    id;

    listData: MatTableDataSource<any[]>;
    displayedColumns: string[] = ['categoryname', 'edit', 'delete'];
    searchKey:string;

    constructor(private route: ActivatedRoute,
        private dialogService: MatDialogService,
        private categoriesService:CategoriesService) { 
          this.id = this.route.snapshot.paramMap.get('id');
    
          this.subscription = this.categoriesService.getAll().subscribe(catgs => {
            this.categories = catgs;
            console.log(this.categories);
            });
    
        }

    ngOnInit() {
        this.categoriesService.getAll().subscribe(
          list=> {
            this.listData = new MatTableDataSource(list);
          //  this.listData.sort = this.sort;
          //  this.listData.paginator = this.paginator;
          }
        );       
      }

      delete(key) {
        this.dialogService.openConfirmDialog('Are you sure to delete this record?')
        .afterClosed().subscribe(res => {
          if(res) {
            this.categoriesService.delete(key);
          }
        }); 
      } 

      ngOnDestroy() {
        this.subscription.unsubscribe();
       }

  }