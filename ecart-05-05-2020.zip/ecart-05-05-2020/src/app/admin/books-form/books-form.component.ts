import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { take } from 'rxjs/operators';
import { Subscription } from 'rxjs';
import { AngularFireStorage } from "@angular/fire/storage";
import { map, finalize } from "rxjs/operators";
import { Observable } from "rxjs";
import { FormGroup, FormControl, Validators } from '@angular/forms';

import { School } from 'src/app/model/school';
import { SchoolService } from 'src/app/services/schools.service';

import { Class } from 'src/app/model/class';
import { ClassService } from 'src/app/services/class.service';
import { Language } from 'src/app/model/languages';
import { LanguagesService } from 'src/app/services/language.service';
import { Category } from 'src/app/model/categories';
import { CategoriesService } from 'src/app/services/categories.service';
import { Publisher } from 'src/app/model/publisher';
import { PublishersService } from 'src/app/services/publishers.service';

import { BooksService } from 'src/app/services/books.service';

@Component({
    selector: 'app-books-form',
    templateUrl: './books-form.component.html',
    styleUrls: []
  })

  export class BooksFormComponent implements OnInit {
    schools:School[];
    classes: Class[];
    languages: Language[];
    categories: Category[];
    publishers: Publisher[];    
    subscription: Subscription; 
    
    book = {};
    id;

    constructor(
    private route: ActivatedRoute,
    private router: Router,
    private storage: AngularFireStorage,
    public schoolservice:SchoolService,
    public classservice:ClassService,
    public languagesService:LanguagesService,
    public categoriesService:CategoriesService,
    public publishersService:PublishersService,
    public booksService: BooksService) {
    this.id = this.route.snapshot.paramMap.get('id');
    console.log("Book ID", this.id);

    // Important line of code to get single product from firebase
    if(this.id) this.booksService.get(this.id).valueChanges().
    pipe(take(1)).subscribe(p => this.book = p);

    this.subscription = this.schoolservice.getAll().subscribe(sch => {
      this.schools = sch;
      console.log(this.schools);
    });

    }

    save(book) {
        console.log(book);
        if(this.id) this.booksService.update(this.id, book)
        else 
        this.booksService.create(book);    
        this.router.navigate(['/admin/books']);        
      }

    ngOnInit() { } 

  }