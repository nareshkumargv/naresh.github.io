import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { take } from 'rxjs/operators';

import { LanguagesService } from 'src/app/services/language.service';

@Component({
    selector: 'app-languages-form',
    templateUrl: './languages-form.component.html',
    styleUrls: []
  })

  export class LanguagesFormComponent implements OnInit {
    language = {};
    id;

    constructor(
      private route: ActivatedRoute,
      private router: Router,
      private languageService: LanguagesService) {
        this.id = this.route.snapshot.paramMap.get('id');
        console.log("Language ID", this.id);

        // Important line of code to get single board from firebase
        // if(this.id) this.languageService.get(this.id).valueChanges().
        // pipe(take(1)).subscribe(p => this.language = p);
      }

      save(language) {
        console.log(language);
        if(this.id) this.languageService.update(this.id, language)
        else 
        this.languageService.create(language);    
        this.router.navigate(['/admin/languages']);        
    }

    ngOnInit() { }

  }