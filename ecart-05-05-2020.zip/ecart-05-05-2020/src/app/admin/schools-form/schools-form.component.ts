import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { take } from 'rxjs/operators';
import { Subscription } from 'rxjs';
import { AngularFireStorage } from "@angular/fire/storage";
import { map, finalize } from "rxjs/operators";
import { Observable } from "rxjs";

import { Boards } from 'src/app/model/boards';
import { BoardsService } from 'src/app/services/boards.service';
import { States } from 'src/app/model/states';
import { StatesService } from 'src/app/services/states.service';
import { Cities } from 'src/app/model/cities';
import { CitiesService } from 'src/app/services/cities.service';

import { SchoolService } from 'src/app/services/schools.service';

@Component({
  selector: 'app-schools-form',
  templateUrl: './schools-form.component.html',
  styleUrls: []
})
export class SchoolsFormComponent implements OnInit {
  states: States[];
  cities: Cities[];
  boards: Boards[];
  subscription: Subscription;

  board: any;
  selectedState: any;
  selectedcity: any;
  statekey: any;

  school = {};
  id;
  //imgSrc: string;
  imgSrc = '../../../assets/images/logo/your-logo.png';
  selectedImage: any = null;
  isSubmitted: boolean;

  selectedFile: File = null;
  fb;
  downloadURL: Observable<string>;

  constructor(
    private router: Router, private storage: AngularFireStorage,
    private route: ActivatedRoute,
    private statesService: StatesService,
    private citiesService: CitiesService,
    private boardsService: BoardsService,
    private schoolservice: SchoolService) {

    this.subscription = this.boardsService.getAll().subscribe(boards => {
      this.boards = boards;
      console.log(this.boards);
    });

    this.subscription = this.statesService.getAll().subscribe(states => {
      this.states = states;
      console.log(this.states);
    });

    this.subscription = this.citiesService.getAll().subscribe(cities => {
      this.cities = cities;
      console.log(this.cities);
    });

    this.id = this.route.snapshot.paramMap.get('id');
    console.log("School ID", this.id);

    // Important line of code to get single product from firebase
    if (this.id) this.schoolservice.get(this.id).valueChanges().
      pipe(take(1)).subscribe(p => this.school = p);

  }

  onSelectState() {
    console.log(this.statekey);
    this.selectedcity = this.cities.filter((scity) => scity.statekey == this.selectedState);
    console.log(this.selectedcity);
  }

  // save(school) {
  //     console.log(school);
  //     if(this.id) this.schoolservice.update(this.id, school)
  //     else 
  //     this.schoolservice.create(school);        
  //     this.router.navigate(['/admin/schools']);
  //     console.log(school);
  //   }

  showPreview(event: any) {
    if (event.target.files && event.target.files[0]) {
      const reader = new FileReader();
      reader.onload = (e: any) => this.imgSrc = e.target.result;
      reader.readAsDataURL(event.target.files[0]);
      this.selectedImage = (event.target.files[0]);
    }
    else {
      this.imgSrc = '../../../assets/images/logo/your-logo.png';
      this.selectedImage = null;
    }
  }

  save(school) {
    console.log(school);
    if (this.id) this.schoolservice.update(this.id, school)
    else

    var filePath = `${'schoollogos'}/${this.selectedImage.name.split('.').slice(0, -1).join('.')}_${new Date().getTime()}`;
    const fileRef = this.storage.ref(filePath);
    this.storage.upload(filePath, this.selectedImage).snapshotChanges().pipe(
      finalize(() => {
        fileRef.getDownloadURL().subscribe((url) => {
          school['imageUrl'] = url;
          this.schoolservice.create(school);
          this.router.navigate(['/admin/schools']);
          //  this.resetForm();
        })
      })
    ).subscribe();

    // this.schoolservice.create(school);        
    // this.router.navigate(['/admin/schools']);
    // console.log(school);
  }




  onFileSelected(event) {
    var n = Date.now();
    const file = event.target.files[0];
    const filePath = `RoomsImages/${n}`;
    const fileRef = this.storage.ref(filePath);
    const task = this.storage.upload(`RoomsImages/${n}`, file);
    task
      .snapshotChanges()
      .pipe(
        finalize(() => {
          this.downloadURL = fileRef.getDownloadURL();
          this.downloadURL.subscribe(url => {
            if (url) {
              this.fb = url;
            }
            console.log(this.fb);
          });
        })
      )
      .subscribe(url => {
        if (url) {
          console.log(url);
        }
      });
  }


  ngOnInit() { }
}