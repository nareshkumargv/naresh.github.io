import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { take } from 'rxjs/operators';

import { ClassService } from 'src/app/services/class.service';

@Component({
    selector: 'app-class-form',
    templateUrl: './class-form.component.html',
    styleUrls: []
  })
  export class ClassFormComponent implements OnInit { 
    sclass = {};
    id;

    constructor(
        private route: ActivatedRoute,
        private router: Router,
        private classService: ClassService) {
          this.id = this.route.snapshot.paramMap.get('id');
          console.log("Class ID", this.id);
  
          // Important line of code to get single board from firebase
          // if(this.id) this.classService.get(this.id).valueChanges().
          // pipe(take(1)).subscribe(p => this.sclass = p);
        }

    ngOnInit() { } 

    save(sclass) {
        console.log(sclass);
        if(this.id) 
        this.classService.update(this.id, sclass)
        else 
        this.classService.create(sclass);    
        this.router.navigate(['/admin/class']);        
      }


  }
