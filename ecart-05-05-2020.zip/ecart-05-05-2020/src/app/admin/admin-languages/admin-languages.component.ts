import { Component, OnInit, OnDestroy, ViewChild } from '@angular/core';
import { ActivatedRoute} from '@angular/router';
import { Subscription } from 'rxjs';

import { MatTableDataSource } from '@angular/material/table';
import { MatDialogService } from 'src/app/services/mat-dialog.service';

import { Language } from 'src/app/model/languages';
import { LanguagesService } from 'src/app/services/language.service';

@Component({
    selector: 'app-languages',
    templateUrl: './admin-languages.component.html',
    styleUrls: []
  })
  export class AdminLanguageComponent implements  OnInit, OnDestroy { 
    languages: Language[];
    subscription: Subscription;
    items: Language[] = [];
    itemCount: number;
    dude: any;
    id;

    listData: MatTableDataSource<any[]>;
    displayedColumns: string[] = ['language', 'edit', 'delete'];
    searchKey:string;

    constructor(private route: ActivatedRoute,
      private dialogService: MatDialogService,
      private languagesService:LanguagesService) { 
        this.id = this.route.snapshot.paramMap.get('id');
  
        this.subscription = this.languagesService.getAll().subscribe(langs => {
          this.languages = langs;
          console.log(this.languages);
          });
  
      }

    ngOnInit() {
        this.languagesService.getAll().subscribe(
          list=> {
            this.listData = new MatTableDataSource(list);
          //  this.listData.sort = this.sort;
          //  this.listData.paginator = this.paginator;
          }
        );
      }

      delete(key) {
        this.dialogService.openConfirmDialog('Are you sure to delete this record?')
        .afterClosed().subscribe(res => {
          if(res) {
            this.languagesService.delete(key);
          }
        }); 
      } 

    ngOnDestroy() {
        this.subscription.unsubscribe();
    }

  }