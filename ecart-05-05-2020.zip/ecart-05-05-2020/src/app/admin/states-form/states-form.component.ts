import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { take } from 'rxjs/operators';

import { StatesService } from 'src/app/services/states.service';

@Component({
    selector: 'app-states-form',
    templateUrl: './states-form.component.html',
    styleUrls: []
  })
  export class StatesFormComponent implements OnInit {
    state = {};
    id;

    constructor(
        private route: ActivatedRoute,private router: Router,
        private statesService: StatesService) {
          this.id = this.route.snapshot.paramMap.get('id');
          console.log("State ID", this.id);
  
          // Important line of code to get single board from firebase
          if(this.id) this.statesService.get(this.id).valueChanges().
          pipe(take(1)).subscribe(p => this.state = p);
        }

        save(state) {
            console.log(state);
            if(this.id) this.statesService.update(this.id, state)
            else 
            this.statesService.create(state);    
            this.router.navigate(['/admin/states']);        
          }



    ngOnInit() { } 

   }