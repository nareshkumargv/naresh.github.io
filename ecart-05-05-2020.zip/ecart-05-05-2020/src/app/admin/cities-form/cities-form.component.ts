import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { take } from 'rxjs/operators';
import { Subscription } from 'rxjs';

import { States } from 'src/app/model/states';
import { StatesService } from 'src/app/services/states.service';
import { CitiesService } from 'src/app/services/cities.service';

@Component({
    selector: 'app-cities-form',
    templateUrl: './cities-form.component.html',
    styleUrls: []
  })

  export class CitiesFormComponent implements OnInit { 
    states: States[];
    cities = {};
    id;
    subscription: Subscription;

    constructor(
        private route: ActivatedRoute,private router: Router,
        private citiesService: CitiesService,
        private statesService:StatesService) {

            this.subscription = this.statesService.getAll().subscribe(states => {
                this.states = states;
                console.log(this.states);
            }); 

          this.id = this.route.snapshot.paramMap.get('id');
          console.log("City ID", this.id);
  
          // Important line of code to get single board from firebase
          if(this.id) this.citiesService.get(this.id).valueChanges().
          pipe(take(1)).subscribe(p => this.cities = p);
        }

        save(city) {
            console.log(city);
            if(this.id) this.citiesService.update(this.id, city)
            else 
            this.citiesService.create(city);    
            this.router.navigate(['/admin/cities']);        
          }

    ngOnInit() {} 
  }