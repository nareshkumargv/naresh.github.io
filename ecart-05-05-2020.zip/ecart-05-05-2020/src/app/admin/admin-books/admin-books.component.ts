import { Component, OnInit, OnDestroy, ViewChild } from '@angular/core';
import { ActivatedRoute} from '@angular/router';
import { Subscription } from 'rxjs';

import { MatTableDataSource } from '@angular/material/table';
import { MatDialogService } from 'src/app/services/mat-dialog.service';

import {Books} from 'src/app/model/books';
import { BooksService } from 'src/app/services/books.service';

@Component({
    selector: 'app-admin-books',
    templateUrl: './admin-books.component.html',
    styleUrls: []
  })
  export class AdminBooksComponent implements OnInit, OnDestroy {

books: Books[];
subscription: Subscription;
items: Books[] = [];
itemCount: number;
dude: any;
id;

listData: MatTableDataSource<any[]>;
displayedColumns: string[] = ['title', 'price','cover', 'edit', 'delete'];
searchKey:string;

constructor(private bookService: BooksService,
  private route: ActivatedRoute,
  private dialogService: MatDialogService) { 
    this.id = this.route.snapshot.paramMap.get('id');
    
    this.subscription = this.bookService.getAll().subscribe(books => {
    this.books = books;
    });
  }

  applyFilter() {
    this.listData.filter = this.searchKey.trim().toLowerCase();
  }

  onClear() {
    this.searchKey = "";
    this.applyFilter();
  }

  delete(key) {
    this.dialogService.openConfirmDialog('Are you sure to delete this record?')
    .afterClosed().subscribe(res => {
      if(res) {
        this.bookService.delete(key);
      }
    }); 
  } 

  ngOnInit() {
    this.bookService.getAll().subscribe(
      list=> {
        this.listData = new MatTableDataSource(list);
      //  this.listData.sort = this.sort;
      //  this.listData.paginator = this.paginator;
      }
    );
  }

    ngOnDestroy() {
       this.subscription.unsubscribe();
      }

  }