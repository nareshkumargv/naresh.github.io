import { Injectable } from '@angular/core';
import { AngularFireDatabase, AngularFireList, AngularFireObject } from '@angular/fire/database';
import { map } from 'rxjs/operators';
import { FirebaseFirestore } from '@angular/fire';

import { Publisher } from '../model/publisher';

@Injectable({
    providedIn: 'root'
  })
  export class PublishersService { 
    publishers: AngularFireList<Publisher>;
    itemRef : any;
    items: Publisher[] = [];

    constructor(private db: AngularFireDatabase) {
        this.getpublishers();
      }

      getpublishers() {
        this.publishers = this.db.list("publishers");
        return this.publishers;
        console.log(this.publishers);
      }

      create(publisher:any) {
        console.log(publisher);
        this.publishers.push(publisher);
      }

       // This code worked for me for retrieving keys from firebase
    getAll() { 
        this.itemRef =  this.db. list('/publishers').snapshotChanges().pipe(map(changes => {
          return changes.map(c => ({ key: c.payload.key, ...c.payload.val() }));
        }));
        return this.itemRef;
      }

      get(publisherId) {
        return this.db.object('/publishers/' +publisherId);
      }  

      update(publisherId, publishers) {
        return this.db.object('/publishers/' + publisherId).update(publishers);
      }
    
      delete(publisherId) {
        return this.db.object('/publishers/' + publisherId).remove(); 
      }

  }