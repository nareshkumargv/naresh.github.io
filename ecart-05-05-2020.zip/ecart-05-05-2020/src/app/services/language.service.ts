import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { AngularFireDatabase, AngularFireList, AngularFireObject } from '@angular/fire/database';
import { map } from 'rxjs/operators';
import { FirebaseFirestore } from '@angular/fire';
import { BehaviorSubject } from 'rxjs';

import { Language } from '../model/languages';

@Injectable({
    providedIn: 'root'
  })
  export class LanguagesService { 

    languages: AngularFireList<Language>;
    itemRef : any;
    items: Language[] = [];

    onCustomerSelect: BehaviorSubject<any> = new BehaviorSubject<any>(null);
    
    constructor(
      private http: HttpClient,
      private db: AngularFireDatabase) {
        this.getlanguages();
      }

      getlanguages() {
        this.languages = this.db.list("languages");
        return this.languages;
        console.log(this.languages);
      }

      create(language:any) {
        console.log(language);
        this.languages.push(language);
      }

                  // This code worked for me for retrieving keys from firebase
    getAll() { 
        this.itemRef =  this.db. list('/languages').snapshotChanges().pipe(map(changes => {
          return changes.map(c => ({ key: c.payload.key, ...c.payload.val() }));
        }));
        return this.itemRef;
    }

    public async get(languageId) {
        return this.db.object('/languages/' +languageId);
    }  

    update(languageId, languages) {
        return this.db.object('/languages/' + languageId).update(languages);
    }
    
    delete(languageId) {
        return this.db.object('/languages/' + languageId).remove(); 
    }

  }