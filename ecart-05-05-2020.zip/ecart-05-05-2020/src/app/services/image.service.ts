import { Injectable } from '@angular/core';
import { AngularFireDatabase, AngularFireList } from '@angular/fire/database';

import { Image } from '../../app/model/image';

@Injectable({
    providedIn: 'root'
  })
  export class ImageService {
    itemRef : any;
    dataSource:AngularFireList<Image>;  
    items: Image[] = [];

    constructor(private db:AngularFireDatabase) { }

    // getImageDetailList() {
    //     this.images = this.db.list('imageDetails');
    // }

    create(imageDetail) {
    console.log(imageDetail);    
    this.db.list('/images').push(imageDetail);
    }

  }