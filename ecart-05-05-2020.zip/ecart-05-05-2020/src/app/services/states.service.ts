import { Injectable } from '@angular/core';
import { AngularFireDatabase, AngularFireList, AngularFireObject } from '@angular/fire/database';
import { map } from 'rxjs/operators';
import { FirebaseFirestore } from '@angular/fire';

import { States } from '../model/states';

@Injectable({
    providedIn: 'root'
  })
  export class StatesService { 
    states: AngularFireList<States>;
    itemRef : any;
    items: States[] = [];

    constructor(private db: AngularFireDatabase) {
        this.getstates();
      }

      getstates() {
        this.states = this.db.list("states");
        return this.states;
        console.log(this.states);
      }

      create(state:any) {
        console.log(state);
        this.states.push(state);
      }

       // This code worked for me for retrieving keys from firebase
    getAll() { 
        this.itemRef =  this.db. list('/states').snapshotChanges().pipe(map(changes => {
          return changes.map(c => ({ key: c.payload.key, ...c.payload.val() }));
        }));
        return this.itemRef;
      }

      get(statesId) {
        return this.db.object('/states/' +statesId);
      }  

      update(statesId, states) {
        return this.db.object('/states/' + statesId).update(states);
      }
    
      delete(statesId) {
        return this.db.object('/states/' + statesId).remove(); 
      }

  }