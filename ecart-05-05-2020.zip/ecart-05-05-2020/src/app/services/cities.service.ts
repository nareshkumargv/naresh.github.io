import { Injectable } from '@angular/core';
import { AngularFireDatabase, AngularFireList, AngularFireObject } from '@angular/fire/database';
import { map } from 'rxjs/operators';
import { FirebaseFirestore } from '@angular/fire';

import { Cities } from '../model/cities';

@Injectable({
    providedIn: 'root'
  })
  export class CitiesService { 
    cities: AngularFireList<Cities>;
    itemRef : any;
    items: Cities[] = [];

    constructor(private db: AngularFireDatabase) {
        this.getcities();
      }

      getcities() {
        this.cities = this.db.list("cities");
        return this.cities;
        console.log(this.cities);
      }

      create(cities:any) {
        console.log(cities);
        this.cities.push(cities);
      }

 // This code worked for me for retrieving keys from firebase
 getAll() { 
    this.itemRef =  this.db. list('/cities').snapshotChanges().pipe(map(changes => {
      return changes.map(c => ({ key: c.payload.key, ...c.payload.val() }));
    }));
    return this.itemRef;
  }

  get(citiesId) {
    return this.db.object('/cities/' +citiesId);
  }  

  update(citiesId, cities) {
    return this.db.object('/cities/' + citiesId).update(cities);
  }

  delete(citiesId) {
    return this.db.object('/cities/' + citiesId).remove(); 
  }

  }