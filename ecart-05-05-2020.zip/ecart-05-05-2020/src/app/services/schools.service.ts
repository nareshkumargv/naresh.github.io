import { Injectable } from '@angular/core';
import { AngularFireDatabase, AngularFireList, AngularFireObject } from '@angular/fire/database';
import { map } from 'rxjs/operators';
import { FirebaseFirestore } from '@angular/fire';

import { School } from '../model/school';
 
@Injectable({
  providedIn: 'root'
})
export class SchoolService { 

    itemRef : any;

    dataSource: AngularFireList<School>;
    items: School[] = [];

    constructor(private db: AngularFireDatabase) {}

    create(school) {
      this.db.list('/schools').push(school);
    } 

// This code worked for me for retrieving keys from firebase
getAll() { 
    this.itemRef =  this.db. list('/schools').snapshotChanges().pipe(map(changes => {
      return changes.map(c => ({ key: c.payload.key, ...c.payload.val() }));
    }));
    return this.itemRef;
  }
 
  get(schoolId) {
    return this.db.object('/schools/' +schoolId);
  }

  update(schoolId, school) {
    return this.db.object('/schools/' + schoolId).update(school);
  }

  delete(schoolId) {
    return this.db.object('/schools/' + schoolId).remove(); 
  }



}