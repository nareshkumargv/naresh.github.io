import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgModule } from '@angular/core';

import { OwlModule } from 'ngx-owl-carousel';
import { MaterialModule } from './material';
import { FlexLayoutModule } from "@angular/flex-layout";
// Firebase services + enviorment module
import { AngularFireModule } from "@angular/fire";
import { AngularFireDatabaseModule } from '@angular/fire/database';
import { AngularFireAuthModule } from "@angular/fire/auth";
import { AngularFirestoreModule } from '@angular/fire/firestore';

import {AngularFireStorageModule, 
  AngularFireStorageReference, 
  AngularFireUploadTask, 
  StorageBucket} from "@angular/fire/storage";

import { environment } from '../environments/environment';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { MDBBootstrapModule } from 'angular-bootstrap-md';
import { FormsModule } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms'; 

import { AdminLayoutComponent } from './_layout/admin-layout/admin-layout.component';
import { UserLayoutComponent } from './_layout/user-layout/user-layout.component';
import { SiteLayoutComponent } from './_layout/site-layout/site-layout.component';

import { HomeComponent } from './components/home/home.component';
import { AcademicsComponent } from './components/Academics/Academics.component';
import { BsNavbarComponent } from './components/bs-navbar/bs-navbar.component';
import { BsFooterComponent } from './components/bs-footer/bs-footer.component';

import { DefaultComponent } from './components/default/default.component';
import { ProductCardComponent } from './components/product-card/product-card.component';
import { ProductCardDetailsComponent } from './components/product-card-details/product-card-details.component';

import { ProductQuantityComponent } from './components/product-quantity/product-quantity.component';
import { ProductFilterComponent } from './products/product-filter/product-filter.component';
import { MatDialogComponent } from './components/mat-dialog/mat-dialog.component'; 
import { ShoppingCartComponent } from './components/shopping-cart/shopping-cart.component';

import { UserCartComponent } from './components/user-cart/user-cart.component';

import { ProductEditComponent } from './components/product-edit/product-edit.component';

import { BookCardComponent } from './components/book-card/book-card.component';

import { MyOrdersComponent } from './components/my-orders/my-orders.component';
import { ListOrderViewComponent } from './components/list-order-view/list-order-view.component';

import { CategoryService } from './services/category.service'; 
import { ProductService } from './services/product.service'; 
import { UserService } from './services/user.service'; 
import { ShoppingCartService } from './services/shopping-cart.service';
import { OrderService } from './services/order.service'; 
import { PriceService } from './services/price.service'; 
import { GenderService } from './services/gender.service'; 
import { MatDialogService } from './services/mat-dialog.service';
import { ShapeService } from './services/shape.service'; 
import { BandMakeService } from './services/band-make.service';
import { BandService } from './services/band.service'; 
import { DialService } from './services/dial.service';

import { BooksService } from './services/books.service';

import { AuthService } from './services/auth.service'; 
import { AuthGuardService } from './services/auth-guard.service';
import { AdminAuthGuardService } from './services/admin-auth-guard.service';

import { AdminDashboardComponent } from './admin/admin-dashboard/dashboard.component'; 
import { ProductFormComponent } from './admin/product-form/product-form.component';
import { AdminOrdersComponent } from './admin/admin-orders/admin-orders.component';
import { AdminOrderDetailsComponent } from './admin/admin-orderdetails/admin-orderdetails.component';
import { AdminProductsComponent } from './admin/admin-products/admin-products.component';

import { AdminLoginComponent } from './admin/admin-login/admin-login.component';
import { AdminBooksComponent } from './admin/admin-books/admin-books.component';
import { BooksFormComponent } from './admin/books-form/books-form.component';
import { BookEditComponent } from './admin/books-edit/books-edit.component';

import { AdminClassBooksComponent } from './admin/admin-classbooks/admin-classbooks.component';
import { ClassBooksFormComponent } from './admin/classbooks-form/classbooks-form.component';

import { AdminBoardComponent } from './admin/admin-boards/admin-boards.component';
import { BoardsFormComponent } from './admin/boards-form/boards-form.component';

import { AdminStateComponent } from './admin/admin-states/admin-states.component';
import { StatesFormComponent } from './admin/states-form/states-form.component';

import { AdminCitiesComponent } from './admin/admin-cities/admin-cities.component';
import { CitiesFormComponent } from './admin/cities-form/cities-form.component';

import { AdminCategoriesComponent } from './admin/admin-categories/admin-categories.component';
import { CategoriesFormComponent } from './admin/categories-form/categories-form.component';

import { AdminLanguageComponent } from './admin/admin-languages/admin-languages.component';
import { LanguagesFormComponent } from './admin/languages-form/languages-form.component';

import { AdminPublishersComponent } from './admin/admin-publishers/admin-publishers.component';
import { PublishersFormComponent } from './admin/publishers-form/publishers-form.component';

import { AdminSchoolsComponent } from './admin/admin-schools/admin-schools.component';
import { SchoolsFormComponent } from './admin/schools-form/schools-form.component';

import { AdminClassComponent } from './admin/admin-class/admin-class.component';
import { ClassFormComponent } from './admin/class-form/class-form.component';

import { CheckOutComponent } from './components/check-out/check-out.component';
import { ShoppingCartSummaryComponent } from './components/shopping-cart-summary/shopping-cart-summary.component';
import { SignInComponent } from './components/sign-in/sign-in.component';
import { SignUpComponent } from './components/sign-up/sign-up.component';
import { ForgotPasswordComponent } from './components/forgot-password/forgot-password.component';
import { VerifyEmailComponent } from './components/verify-email/verify-email.component';
import { DashboardComponent } from './components/dashboard/dashboard.component';

import { ProductDetailsComponent } from './product-details/product-details.component';

import { PopupLoginComponent } from './components/popup-login/popup-login.component';
import { OrderDetailsComponent } from './components/order-details/order-details.component';

import { SearchComponent } from './components/search/search.component';
import { SchoolsListComponent } from './components/schoolslist/schoolslist.component';
import { SchoolsDetailsComponent } from './components/school-details/school-details.component';

import { ImageUploadComponent } from './components/image-upload/image-upload.component';
import { HttpClientModule } from '@angular/common/http';
@NgModule({
  declarations: [
    AppComponent,
    AdminLayoutComponent,UserLayoutComponent,SiteLayoutComponent,
    BsNavbarComponent,
    BsFooterComponent,
    HomeComponent,AcademicsComponent,
    ShoppingCartComponent,UserCartComponent,
    DefaultComponent,
    ProductCardComponent,ProductCardDetailsComponent,
    BookCardComponent,
    ProductQuantityComponent,
    ProductFilterComponent,MatDialogComponent, DashboardComponent,ProductEditComponent,
    ProductFormComponent,
    AdminOrdersComponent,AdminOrderDetailsComponent,
    AdminProductsComponent,ListOrderViewComponent,
    AdminBooksComponent,BooksFormComponent,BookEditComponent,
    CheckOutComponent,ShoppingCartSummaryComponent, 
    SignInComponent, SignUpComponent, ForgotPasswordComponent, VerifyEmailComponent,
    ProductDetailsComponent,PopupLoginComponent,
    MyOrdersComponent,OrderDetailsComponent,
    AdminLoginComponent,AdminDashboardComponent,
    AdminBoardComponent,BoardsFormComponent,
    AdminStateComponent,StatesFormComponent,
    AdminCitiesComponent,CitiesFormComponent,
    AdminSchoolsComponent,
    SearchComponent,
    SchoolsListComponent,SchoolsFormComponent,SchoolsDetailsComponent,
    AdminCategoriesComponent,CategoriesFormComponent,
    AdminLanguageComponent,LanguagesFormComponent,
    AdminPublishersComponent,PublishersFormComponent,
    AdminClassComponent,ClassFormComponent,
    AdminClassBooksComponent,ClassBooksFormComponent,
    ImageUploadComponent
  ],
  imports: [
    BrowserModule,MaterialModule,OwlModule,HttpClientModule,
    FormsModule,ReactiveFormsModule,
    AppRoutingModule,FlexLayoutModule,
    BrowserAnimationsModule,
    MDBBootstrapModule.forRoot(),    
    AngularFireDatabaseModule,
    AngularFireAuthModule,
    AngularFirestoreModule,
    AngularFireStorageModule,
    AngularFireModule.initializeApp(environment.firebase, "cloud")
  ],
  providers: [CategoryService, AuthService, AuthGuardService, UserService,
    AdminAuthGuardService, ProductService, ShoppingCartService,OrderService,
    GenderService, PriceService, MatDialogService, ShapeService, BandMakeService,
    DialService, BandService, BooksService,
    { provide: StorageBucket, useValue: "gs://mystore-ff1f3.appspot.com" }
  ],
    entryComponents: [MatDialogComponent],
  bootstrap: [AppComponent]
})
export class AppModule { }
