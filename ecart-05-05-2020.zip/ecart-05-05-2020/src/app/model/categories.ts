export class Category {
    key: string;
    categoryname: string;   
 }