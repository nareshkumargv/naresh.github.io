export class Cities {
    key: string;
    statekey: string;   
    cityname:string;
 }