export class Language {
    key: string;
    language: string;   
 }