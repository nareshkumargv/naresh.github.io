import { Component, OnInit,Output,EventEmitter,Input } from '@angular/core'; 
import { ActivatedRoute} from '@angular/router';
import {Router} from "@angular/router";
import { Subscription, Observable } from 'rxjs';

import { ShoppingCartService } from 'src/app/services/shopping-cart.service';
import { ShoppingCart } from 'src/app/model/shopping-cart';
import { LanguagesService } from 'src/app/services/language.service';
import { ClassService } from 'src/app/services/class.service';

@Component({
  selector: 'user-cart',
  templateUrl: './user-cart.component.html',
  styleUrls: ['./user-cart.component.scss']
})
export class UserCartComponent implements OnInit { 

  schoolid:any;
  public sub: any;
  Languages:any = [];
  selectedlanguage:any;

  Classes:any = [];
  selectedclass:any;
  userselclass:any = [];

  subscription: Subscription;  
  cart$:Observable<ShoppingCart>;

    constructor(
      private router:Router,
      private route: ActivatedRoute,
      private _classapi:ClassService,
      private _languagesapi:LanguagesService,
      private cartService: ShoppingCartService) {

      this.sub = this.route.params.subscribe(params => {
          this.schoolid = params['key'];                 
      });

        this.subscription = this._classapi.getAll().subscribe(sclass => {
          this.Classes = sclass;
          console.log(this.Classes);
      }); 

        this.subscription = this._languagesapi.getAll().subscribe(langs => {
          this.Languages = langs;
          console.log(this.Languages);
      });
       }
    
    // async ngOnInit() {
    //  this.cart$ = await this.cartService.getCart();
    //  console.log(this.cart$);
    // }
  
    public async ngOnInit(): Promise<void> { 
      this.cart$ = await this.cartService.getCart();
      //  console.log(this.cart$);

      this._classapi.onCustomerSelect.subscribe(value => {
        console.log('FROM Display Comp -----', value);
        this.selectedclass = value;
        console.log(this.selectedclass);

        if (this.selectedclass) { 
        this._classapi.get(this.selectedclass).then(Response => {
            console.log(Response);            
          })
        }

        // if (this.selectedclass) { 
        //   this.userselclass = this._classapi.get(this.selectedclass).set(Response => {
        //       console.log(Response);            
        //     })
        //   }
      })

      this._languagesapi.onCustomerSelect.subscribe(value => {
        console.log('FROM Display Comp -----', value);
        this.selectedlanguage = value;
        console.log(this.selectedlanguage);

        if (this.selectedlanguage) { 
          this._languagesapi.get(this.selectedlanguage).then(Response => {
              console.log(Response);            
            })
          }

      })

    }






    clearCart() {
      this.cartService.clearCart();
    }

    checkout(sname:any, sno:any) {
        console.log('Student Name'+ sname);
        console.log('Student Admission'+ sno);
        this.router.navigate(['components/check-out', sname,sno]);
    }




}