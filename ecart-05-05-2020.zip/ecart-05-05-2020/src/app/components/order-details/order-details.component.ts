import { Component, OnInit, Input } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';

import { OrderService } from 'src/app/services/order.service';
import { AuthService } from 'src/app/services/auth.service';
import { switchMap } from 'rxjs/operators';

import { Order } from 'src/app/model/order';

@Component({
    selector: 'app-order-details',
    templateUrl: './order-details.component.html',
    styleUrls: [],
    providers: []
  })
  export class OrderDetailsComponent implements OnInit { 
    id;
    orders:Order[] = [];
    orderlist:any;
    selectedorder: any[] = []; 
    selproducts:any;

    constructor(
        private route: ActivatedRoute,
        private router: Router,
        private orderService: OrderService) {
        this.id = this.route.snapshot.paramMap.get('key');
      //  console.log("Order ID", this.id);     
    }
    
    ngOnInit() { 
      this.orderService.getAllOrders().subscribe(orders=> {
        this.orderlist= orders;
      //  console.log(this.orderlist);

       this.selectedorder = this.orderlist.filter((odata) => odata.key == this.id);
       //console.log(this.selectedorder);
       this.selproducts = this.selectedorder[0].items;
        // console.log(this.selproducts);

        // this.selectedorder[0].items.map(data => {
        //   this.selproducts = data;
        //   console.log(this.selproducts);
        // })

      })

    }

  }