import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import { filesuploadService } from '../services/fileupload.service';
import { HistoryService } from '../services/history.service';

@Component({
  selector: 'app-jobqueue-view',
  templateUrl: './jobqueue-view.component.html',
  styleUrls: ['./jobqueue-view.component.css']
})
export class JobqueueViewComponent implements OnInit {
  uploadfiles:any[]=[];
  uploadedFiles: any[] = [];

  jobhistory:any[]=[];

  display: boolean = false;

  cols: any[];
  hcols: any[];

  val1: string = 'Option 1';

  public show:boolean = true;  
  public labelName:any = 'Collapse List Of Check Lists';

  public showicon:boolean = true;  
  
  classtoggle:object;  
  toggleicon:object;

  htypes: Histypes[];
  selectedhtype: Histypes;
  
  constructor(private uploadedfiles: filesuploadService, private historyservice: HistoryService, private router: Router) {
    
    this.htypes = [
      {name: 'All', code: 'Opt1'},
      {name: 'Job Queue', code: 'Opt2'},
      {name: 'Check List', code: 'Opt3'}      
  ];

  }

  ngOnInit() {
    this.uploadedfiles.getfilesupload().subscribe(data  => {
      this.uploadfiles = data['fileuploaddata'];      
    });

    this.cols = [      
      { field: 'fname', header: 'File Name' },
      { field: 'uploadedby', header: 'Uploaded By' },
      { field: 'uploadedon', header: 'Uploaded On' }      
    ];

  this.historyservice.getHistory().subscribe(data  => {
    this.jobhistory = data['historydata'];      
    //console.log(this.jobhistory);
  });

  this.hcols = [      
    { field: 'change', header: 'Change' },
    { field: 'changedby', header: 'Changed By' },
    { field: 'changetype', header: 'Change Type' },     
    { field: 'changedate', header: 'Change Date' }      
  ];

  }

  onUpload(event) {
    for(let file of event.files) {
        this.uploadedFiles.push(file);
    }
  }

  showDialog() {
    this.display = true;   
  }

  createchecklistbtn() {
        this.router.navigateByUrl('/createchecklist');
};

  toggle() {
    this.show = !this.show;
    this.showicon = !this.showicon;

    if (this.show)
      this.labelName = "Collapse List Of Check Lists";        
    else
      this.labelName = "Expand List Of Check Lists";

    this.classtoggle = {
      "col-md-12":!this.show,
      "col-md-10":this.show
    }

    this.toggleicon = {
      "arrows-1_minimal-left":this.showicon,
      "arrows-1_minimal-right":!this.showicon
    }

  }
  
}

interface Histypes {
  name: string;
  code: string;
}
