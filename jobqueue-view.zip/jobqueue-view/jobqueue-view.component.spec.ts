import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { JobqueueViewComponent } from './jobqueue-view.component';

describe('JobqueueViewComponent', () => {
  let component: JobqueueViewComponent;
  let fixture: ComponentFixture<JobqueueViewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ JobqueueViewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(JobqueueViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
