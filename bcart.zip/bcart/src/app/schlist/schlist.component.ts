import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Routes,Router } from '@angular/router';

import { BoardsApiService } from "../shared/services/boards-api.service";
import { StatesApiService } from "../shared/services/states-api.service";
import { CitiesApiService } from "../shared/services/cities-api.service";
import { SchoolsApiService } from "../shared/services/schools-api.service";

@Component({
    selector: 'app-schlist',
    templateUrl: './schlist.component.html',
    styleUrls: [],
    providers:[BoardsApiService,StatesApiService,CitiesApiService,SchoolsApiService]
  })
  export class SchlistComponent implements OnInit { 
    Board: any = [];
    States:any = [];
    Cities:any = [];
    Schools:any = [];  
    
    selectedBoard: Boards;
    selectedState: States;
    selectedCity:Cities;
  
    boardsservicedata:any = [];
    statesservicedata:any = [];
    citiesservicedata:any = [];
    schoolsservicedata:any = [];

    selectedschool:any =[];

    bid: any;
    sid: any;
    cid: any;
    public sub: any;

    constructor(private route: ActivatedRoute,
        private router:Router, 
        public _boardapi:BoardsApiService,
        public _statesapi:StatesApiService,
        public _citiesapi:CitiesApiService,
        public _schoolsapi:SchoolsApiService
    ) {}

    ngOnInit() {
        this.sub = this.route.params.subscribe(params => {
            this.bid = params['Bid'];
            this.sid = params['Sid'];
            this.cid = params['Cid'];
            console.log(this.bid,this.sid,this.cid);
          });

        this._schoolsapi.getSchools().subscribe(
            schoolsdata => { this.Schools = schoolsdata
                for (var i = 0; i < this.Schools.length; i++) {
                    if (this.Schools[i].bid == this.bid && this.Schools[i].sid == this.sid && this.Schools[i].cid == this.cid) {
                      this.selectedschool.push(this.Schools[i]);
                      console.log(this.selectedschool);
                    }
                }
            },      
            err => console.error(err),
            () => console.log(this.selectedschool)

        )

        // for (var i = 0; i < this.Schools.length; i++) {
        //     if (this.Schools[i].bid == this.bid && this.Schools[i].sid == this.sid && this.Schools[i].cid == this.cid) {
        //       this.selectedschool.push(this.Schools[i]);
        //       console.log(this.selectedschool);
        //     }
        // }
          
            // this._boardapi.getBoards().subscribe(
            //   boardsdata => { return this.Board = boardsdata},      
            //   err => console.error(err),
            //   () => console.log(this.Board)      
            // );          
          
            // this._statesapi.getStates().subscribe(
            //   statesdata => { return this.States = statesdata},      
            //   err => console.error(err),
            //   () => console.log(this.States)      
            // );
          
            // this._citiesapi.getCities().subscribe(
            //   citiesdata => { return this.Cities = citiesdata},      
            //   err => console.error(err),
            //   () => console.log(this.Cities)      
            // );
            // this._schoolsapi.getSchools().subscribe(
            //     schoolsdata => { return this.Schools.filter((sch)=> sch.bid == this.bid && sch.sid == this.sid && sch.cid == this.cid) },      
            //     err => console.error(err),
            //     () => console.log(this.Schools)      
            // );

            // this.selectedschool = this.Schools.filter((sch) => sch.bid == this.bid && sch.sid == this.sid && sch.cid == this.cid);
            // console.log(this.selectedschool);
     }    



  }

  export class Boards {
    id: number;
    name: string;   
  } 
  export class States {
    id: number;
    name: string;   
  }
  export class Cities {
    id: number;
    sid:number;
    name: string;   
  } 