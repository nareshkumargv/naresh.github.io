import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';

@Injectable()

export class BoardsApiService {

apiURL = 'http://localhost:3000';
constructor(private _http: HttpClient) { }
 
  //Get Boards
  getBoards():Observable<Object> {
    return this._http.get(this.apiURL + '/boards');
  }

}

