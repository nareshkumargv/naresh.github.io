import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable()
  
export class CitiesApiService {

  apiURL = 'http://localhost:3000';
  constructor(private http: HttpClient) { }

    //Get cities
    getCities():Observable<Object> {
      return this.http.get(this.apiURL + '/cities');
    }

}