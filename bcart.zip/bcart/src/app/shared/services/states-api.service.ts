import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable()
 
export class StatesApiService {
  
    apiURL = 'http://localhost:3000';
    constructor(private _http: HttpClient) { }
     
      //Get States
      getStates():Observable<Object> {
        return this._http.get(this.apiURL + '/states');
      }


  }