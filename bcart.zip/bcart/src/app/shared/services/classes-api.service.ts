import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';

@Injectable()

export class ClassesApiService {

apiURL = 'http://localhost:3000';
constructor(private _http: HttpClient) { }
 
  //Get Boards
  getClasses():Observable<Object> {
    return this._http.get(this.apiURL + '/classes');
  }

}

