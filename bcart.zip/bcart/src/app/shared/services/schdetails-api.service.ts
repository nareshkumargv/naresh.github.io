import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';

@Injectable()

export class SchDetailsApiService {

apiURL = 'http://localhost:3000';
constructor(private _http: HttpClient) { }
 
  //Get schools
  getSchoolsDetails():Observable<Object> {
    return this._http.get(this.apiURL + '/schooldetails');
  }

//   getSchDetailsbyid(id) {
//     return this._http.get(`${this.apiURL + 'products'}/${id}`)
// }


}
