export class Language {
    id: number;
    sid:number;
    classid:number;
    languagename: string;   
 } 