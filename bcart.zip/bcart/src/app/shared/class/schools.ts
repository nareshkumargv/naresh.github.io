export class Schools {
    id: number;
    bid:number;
    sid:number;
    cid:number;    
    sname: string;   
} 