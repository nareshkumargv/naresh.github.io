export class Classes {
    id: number;
    sid:number;
    name: string;   
 } 