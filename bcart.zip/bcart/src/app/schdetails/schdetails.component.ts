import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Routes,Router } from '@angular/router';

import { SchoolDetails } from '../shared/class/schooldetails';
import { SchDetailsApiService } from '../shared/services/schdetails-api.service';

import { Classes } from '../shared/class/classes';
import { ClassesApiService } from  '../shared/services/classes-api.service';

import { Language } from '../shared/class/language';
import { LanguageApiService } from  '../shared/services/language-api.service';

import {ApiService} from '../shared/services/api.service';
import { DataShareService } from '../shared/services/data-share.service';
import { LocalStorageService } from '../shared/services/local-storage.service';
import { DataToCart } from '../shared/class/data-to-cart';

@Component({
    selector: 'app-schdetails',
    templateUrl: './schdetails.component.html',
    styleUrls: [],
    providers:[SchDetailsApiService,ClassesApiService,LanguageApiService]
  })
  export class SchDetailsComponent implements OnInit { 

    schdetails: SchoolDetails[] = [];
    schdetailsdata:any = [];
    selectedschlist:any =[];

    classdetails: Classes[] = [];
    classesdata:any = [];
    classeslist:any =[];

    langdetails: Language[] =[];
    langdata:any = [];
    langlist:any = [];
    languagedatalist:any = [];
    lngcheckedList:any;

    public sid:any;
    public sub: any;

    books;
    cart:any[];
    cartLength:number;
    storageName:string;
    key:any;
    classbooksdata:any =[];
    booksfilter:any;

    constructor(private route: ActivatedRoute,
    private router:Router,
    public _schdetailsapi:SchDetailsApiService,
    public _classesdetailsapi:ClassesApiService,
    public _languageapi:LanguageApiService,
    private _bookService:ApiService, 
    private _dataShareService:DataShareService,
    private _localStorageService:LocalStorageService,
    ) {}

    ngOnInit() {
        
        this.cartLength = 0        
        this.cart = [];
        this.storageName = "cartCleared";
        //this.getData();


        this.sub = this.route.params.subscribe(params => {
            this.sid = params['id'];
            console.log(this.sid);
        });

        this._schdetailsapi.getSchoolsDetails().subscribe(
            schdetails => { this.schdetailsdata = schdetails
            this.selectedschlist = this.schdetailsdata.filter((schlist) => schlist.id == this.sid)},
            err => console.error(err),
            () => console.log(this.selectedschlist) 
        )

        this._classesdetailsapi.getClasses().subscribe(
            classdetails => { this.classesdata = classdetails
            this.classeslist = this.classesdata.filter((clslist) => clslist.sid == this.sid)},
            err => console.error(err),
            () => console.log(this.classeslist) 
        )

        this._languageapi.getLanguages().subscribe(
            langdetails => { this.langdata = langdetails
            this.langlist = this.langdata.filter((lnglist) => lnglist.sid == this.sid)},
            err => console.error(err),
            () => console.log(this.langlist) 
        )

        this._bookService.getBooks().subscribe(
            data => { return this.books = data},
            err => console.error(err),
            () => console.log('done loading books')
          ); 

          this.booksfilter = this.books;
          console.log(this.booksfilter);

    }

    // getData():any{
    //     this._bookService.getBooks().subscribe(
    //       data => { return this.books = data},
    //       err => console.error(err),
    //       () => console.log('done loading books')
    //     );    
    // }

    
    addToCart(i:number):void{    
    var bookToCart = new DataToCart().setData(this.books,i);
    var cartStatus = this._localStorageService.getLocalstorage(this.books, this.storageName);
    //Check if cart is cleared
    if(cartStatus === 1){
      this.cart = [];      
      this._localStorageService.setLocalstorage(0, this.storageName);
      this.cart.push(bookToCart);
        }else{
      this.cart = this.cart;
      this.cart.push(bookToCart);
    }
    this.passData(this.cart);
      }

    passData(cart:any[]):void{
    this.cart = cart;
    this._dataShareService.sendData(this.cart);
    }

    onSelectClass(id) {
        console.log(id);
        this.languagedatalist = this.langlist.filter((ldata) => ldata.classid == id);
        console.log(this.languagedatalist);
    }

    onlanguageSelect() { 
        this.lngcheckedList = [];
        for (var i = 0; i < this.languagedatalist.length; i++) {
            if(this.languagedatalist[i].isSelected)
            this.lngcheckedList.push(this.languagedatalist[i]);
            console.log(this.lngcheckedList);
        }
        this.classbooksdata = [];
        this.books.forEach((cbooks,i) => { 
            this.lngcheckedList.forEach((selectedLang,i) => { 
                if(selectedLang.id == cbooks.language) {
                    //console.log(cbooks);
                    this.classbooksdata.push(cbooks);
                    console.log(this.classbooksdata);
                }
            });
        });
        console.log(this.classbooksdata);
    }          
          

    }

  