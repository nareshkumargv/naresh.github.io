import { Component, OnInit } from '@angular/core';
import {Router} from "@angular/router";
import {forkJoin} from "rxjs/observable/forkJoin";

import { BoardsApiService } from "../shared/services/boards-api.service";
import { StatesApiService } from "../shared/services/states-api.service";
import { CitiesApiService } from "../shared/services/cities-api.service";


@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: [],
  providers:[BoardsApiService,StatesApiService,CitiesApiService]
})
export class SearchComponent implements OnInit {
  Board: any = [];
  States:any = [];
  Cities:any = [];  
  Books:any = [];

  selectedBoard: Boards;
  selectedState: States;
  selectedCity:Cities;

  boardsservicedata:any = [];
  statesservicedata:any = [];
  citiesservicedata:any = [];
  booksservicedata:any = [];

  // selectedcity:any;
  // seclectedschool:any;

  page:string;

  constructor(private router:Router, 
  public _boardapi:BoardsApiService,
  public _statesapi:StatesApiService,
  public _citiesapi:CitiesApiService
 ) { }

  ngOnInit() {
    this.page = "search";
    this.getData();
    this.getStatesData();
    this.getCitiesData();
  }

  getData():any{
    this._boardapi.getBoards().subscribe(
      boardsdata => { return this.Board = boardsdata},      
      err => console.error(err),
      () => console.log(this.Board)      
    );
  }

  getStatesData():any{ 
    this._statesapi.getStates().subscribe(
      statesdata => { return this.States = statesdata},      
      err => console.error(err),
      () => console.log(this.States)      
    );
  }

  getCitiesData():any{ 
    this._citiesapi.getCities().subscribe(
      citiesdata => { return this.Cities = citiesdata},      
      err => console.error(err),
      () => console.log(this.Cities)      
    );
  }

  onSelectBoard(Bid) { 
    this.selectedBoard = null;
    for (var i = 0; i < this.Board.length; i++)
    {
      if (this.Board[i].id == Bid) {
        this.selectedBoard = this.Board[i];
      }
    }
}

onSelectState(Sid) {
  this.selectedState = null;
  for (var i = 0; i < this.States.length; i++)
  {
    if (this.States[i].id == Sid) {
      this.selectedState = this.States[i];
    }
  }
}

onSelectCity(Cid) {
  this.selectedCity = null;
  for (var i = 0; i < this.Cities.length; i++)
  {
    if (this.Cities[i].id == Cid) {
      this.selectedCity = this.Cities[i];
    }
  }
}

  search(Bid: any,Sid:any,Cid:any) { 
    console.log(Bid,Sid,Cid);
    this.router.navigate(['/schlist', Bid, Sid, Cid]);
   // this.router.navigate(['/schlist']);
  }
  
}

export class Boards {
  id: number;
  name: string;   
} 
export class States {
  id: number;
  name: string;   
}
export class Cities {
  id: number;
  sid:number;
  name: string;   
} 