import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { HomeComponent } from './components/home/home.component';
import { ShoppingCartComponent } from './components/shopping-cart/shopping-cart.component';

import { DashboardComponent } from './admin/dashboard/dashboard.component'; 
import { ProductFormComponent } from './admin/product-form/product-form.component';
import { AdminOrdersComponent } from './admin/admin-orders/admin-orders.component';
import { AdminProductsComponent } from './admin/admin-products/admin-products.component';

import { ProductEditComponent } from './components/product-edit/product-edit.component';

import { AuthGuardService } from './services/auth-guard.service';
import { AdminAuthGuardService } from './services/admin-auth-guard.service';

import { AdminBooksComponent } from './admin/admin-books/admin-books.component';
import { BooksFormComponent } from './admin/books-form/books-form.component';
import { BookEditComponent } from './admin/books-edit/books-edit.component';

const routes: Routes = [
  {path: '', component: HomeComponent, data: {depth: 1}},
  {path: 'components/shopping-cart', 
  component: ShoppingCartComponent, data: {depth: 2}},
  { 
    path:'admin/products/new', 
    component: ProductFormComponent,data: {depth: 5}
  },
  {
    path:'admin/products/:id', 
    component: ProductEditComponent, data: {depth: 6},
    canActivate:[AuthGuardService, AdminAuthGuardService] 
  },
  {
    path:'admin/products', 
    component: AdminProductsComponent, data: {depth: 7}
  }, 

  {path: 'admin/dashboard', component: DashboardComponent, pathMatch: 'full' },
  {
    path:'admin/books', 
    component: AdminBooksComponent, data: {depth: 7}
  }, 
  { 
    path:'admin/books/new', 
    component: BooksFormComponent,data: {depth: 5}
  },
  {
    path:'admin/books/:id', 
    component: BookEditComponent, data: {depth: 6} 
  }


];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
