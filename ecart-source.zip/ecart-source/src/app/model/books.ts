export interface Books {
    key: string;
    isbn:string;    
    title: string;    
    price: number;
    cover : string;
    synopsis: string;   
}