import { Component, ViewEncapsulation, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import { AdminAuthService } from '../../shared/AdminAuth.service';;

@Component({
    selector: 'app-admin-layout',
    templateUrl: './admin-layout.component.html',
    styleUrls: ['./admin-layout.component.css'],  
    encapsulation: ViewEncapsulation.None
  })
  export class AdminLayoutComponent implements OnInit {
      
  id: string;
  constructor(private router: Router, public authService: AdminAuthService) { }

  ngOnInit() {
    this.id = localStorage.getItem('token');
  }

  logout(): void {
    console.log("Logout");
    this.authService.logout();
    this.router.navigate(['/admin']);
  }
  }