import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule, FormsModule } from "@angular/forms";
import { HttpClientModule, HTTP_INTERCEPTORS } from "@angular/common/http";
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ToastrModule } from 'ngx-toastr';

import { CalendarModule } from 'primeng/calendar';
import { SpinnerModule } from 'primeng/spinner';
import { ButtonModule } from 'primeng/button';
import { CarouselModule } from 'primeng/carousel';
import { RadioButtonModule } from 'primeng/radiobutton';
import { DialogModule } from 'primeng/dialog';
import { SelectButtonModule } from 'primeng/selectbutton';
import { CheckboxModule } from 'primeng/checkbox';
import { SliderModule } from 'primeng/slider';
import { FullCalendarModule } from 'primeng/fullcalendar';

import {FileUploadModule} from 'ng2-file-upload';
import { AgmCoreModule } from '@agm/core';

//import { FullCalendarModule } from 'ng-fullcalendar';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { UserComponent } from './user/user.component';
import { RegistrationComponent } from './user/registration/registration.component';
import { UserService } from './shared/user.service';
import { LoginComponent } from './user/login/login.component';
import { AuthInterceptor } from './auth/auth.interceptor';

import {SiteLayoutComponent} from './_Layouts/site-layout/site-layout.component';
import {ClientLayoutComponent} from './_Layouts/client-layout/client-layout.component';
import {AdminLayoutComponent} from './_Layouts/admin-layout/admin-layout.component';
import { OrgLayoutComponent } from './_Layouts/org-layout/org-layout.component';

import { ClientSignUpComponent } from './client-signup/client-signup.component';
import { ClientLoginComponent } from './client-login/client-login.component';
import { ClientDashboardComponent } from './client/dashboard/dashboard.component';
import { VenueDetailsComponent } from './client/venuedetails/venuedetails.component';
import { FetchVenueDetailsComponent } from './client/fetchvenue/fetchvenue.component';

import { AddVenueComponent } from './client/addvenue/addvenue.component';

import { ClientFacilitiesListComponent } from './client/facilities/facilitieslist.component';
import { AddClientFacilities } from './client/addcfacilities/addcfacilities.component';
import { AddRoomsComponent } from './client/addrooms/addrooms.component';
import { ClientRoomsListComponent } from './client/rooms/rooms.component';

import { MySpaceListComponent } from './client/myspace/myspace.component';
import { AddMySpaceComponent } from './client/addmyspace/addmyspace.component';

import { BusinessHoursComponent } from './client/businesshours/businesshours.component';
import { AddBusinessHoursComponent } from './client/addbusinesshours/addbusinesshours.component';

import { BookingsComponent } from './client/bookings/bookings.component';

import { VenueComponent } from './venue/venue.component';
import { ManageSpaceComponent } from './managespace/managespace.component';

import { OrganisationsComponent } from './org-home/organisations.component';
import { OrgRegistrationComponent } from './org-register/org-register.component';
import { OrgLoginComponent } from './org-login/org-login.component';
import { OrgDashboardComponent } from './organisation/dashboard/org-dashboard.component';
import { OrgProfileComponent } from './organisation/profile/profile.component';
import { OrgDetailsComponent } from './organisation/orgdetails/orgdetails.component';
import { OrgBookingsComponent } from './organisation/bookings/bookings.component';
import { BookingDetailsComponent } from './organisation/bookingdetails/bookingdetails.component';

import { myinfoComponent } from './organisation/myinfo/myinfo.component';

import { AdminLoginComponent } from './admin-login/admin-login.component';
import { AdminDashboardComponent } from './admin/dashboard/admin-dashboard.component';
import { AdminFacilitiesComponent } from './admin/facilities/facilities.component'; 
import { AdminAddFacilitiesComponent } from './admin/addfacilities/addfacilities.component';

import { CateringFacilitiesComponent } from './admin/cateringfacilities/cateringfacilities.component';
import { AddCateringFacilitiesComponent } from './admin/addcateringfacilities/addcateringfacilities.component';

import { FacilitiesService } from './shared/facilities.service';
import { VenueTypeListComponent } from './admin/venuetypes/venuetypes_listing/venuetypes_listing.component';
import { AddVenueTypeComponent } from './admin/venuetypes/venuetypes_add/venuetypes_add.component';

import { VenueHallOptionsComponent } from './admin/venue_halloptions/venue-halloptions.component';
import { AddVenueTypeOptionsComponent } from './admin/addvenue_halloptions/addvenue_halloptions.component';

import { HomeComponent } from './home/home.component';
import { VenuesListComponent } from './venueslist/venueslist.component';
import { FilterComponent } from './filter/filter.component';
import { VenueDetailComponent } from './venuedetails/venuedetails.component';

import { FileUploadComponent } from './client/file-upload/file-upload.component';
import { GeoLocationComponent } from './client/geolocation/geolocation.component';
import { FetchGeoLocationComponent } from './client/fetchgeolocation/fetchgeolocation.component';

import { LoginModalComponent } from './login-modal/login-modal.component';
import { ShoppingCartComponent } from './shopping/shopping-cart/shopping-cart.component';

import { MyCartComponent } from './mycart/mycart.component';

import { UploadComponent } from './organisation/upload/upload.component';

import { ContactFormComponent } from './contact-form/contact-form.component';

import { ForgotPasswordComponent } from './forgot-password/forgot-password.component';
import { ResetPasswordComponent } from './reset-password/reset-password.component';

@NgModule({
  declarations: [
    AppComponent,
    UserComponent,
    RegistrationComponent,
    LoginComponent,
    HomeComponent,
    VenueComponent,
    VenuesListComponent,VenueDetailComponent,
    ManageSpaceComponent,
    ClientSignUpComponent,ClientLoginComponent,
    ClientDashboardComponent,VenueDetailsComponent,AddVenueComponent,FetchVenueDetailsComponent,ClientFacilitiesListComponent,AddClientFacilities,
    AddRoomsComponent,ClientRoomsListComponent,
    OrganisationsComponent,OrgRegistrationComponent,OrgLoginComponent,OrgDashboardComponent,myinfoComponent,
    OrgDetailsComponent,OrgProfileComponent,OrgBookingsComponent,BookingDetailsComponent,
    AdminLoginComponent,AdminDashboardComponent,AdminFacilitiesComponent,AdminAddFacilitiesComponent,
    CateringFacilitiesComponent,AddCateringFacilitiesComponent,
    VenueTypeListComponent,
    AddVenueTypeComponent,VenueHallOptionsComponent,AddVenueTypeOptionsComponent,
    SiteLayoutComponent,ClientLayoutComponent,AdminLayoutComponent,OrgLayoutComponent,    
    FilterComponent,MySpaceListComponent,AddMySpaceComponent,
    BusinessHoursComponent,AddBusinessHoursComponent,
    FileUploadComponent,FetchGeoLocationComponent,GeoLocationComponent,
    LoginModalComponent,BookingsComponent,ShoppingCartComponent,
    MyCartComponent,
    UploadComponent,ContactFormComponent,
    ForgotPasswordComponent,ResetPasswordComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    HttpClientModule,
    BrowserAnimationsModule,
    CalendarModule, SpinnerModule, ButtonModule, CarouselModule, RadioButtonModule,
    DialogModule, SelectButtonModule, CheckboxModule, SliderModule,
    FileUploadModule,FullCalendarModule,
    AgmCoreModule.forRoot({ 
    //  *****apiKey:'AIzaSyA0lqMhpaAiJ26EEMgCLxUnH8byPpPXhTI',
    //apiKey: 'AIzaSyAvcDy5ZYc2ujCS6TTtI3RYX5QmuoV8Ffw',
    // apiKey:'AIzaSyAfJTVKnpLl0ULuuwDuix-9ANpyQhP6mfc'
    //apiKey:'AIzaSyD0HNSWtIXDJ-cbZy47Z8n1rOh_AwpOjDo',
    //apiKey:'AIzaSyAzSnXXXXXXXXXXXXXXXXXSZGGWU',
    libraries: ['places']
    }),
    ToastrModule.forRoot({
      progressBar: true
    }),
    FormsModule
  ],
  providers: [UserService,FacilitiesService, {
    provide: HTTP_INTERCEPTORS,
    useClass: AuthInterceptor,
    multi: true
  }],
  bootstrap: [AppComponent]
})
export class AppModule { }
