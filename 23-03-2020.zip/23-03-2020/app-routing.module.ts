import { AuthGuard } from './auth/auth.guard';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { UserComponent } from './user/user.component';
import { RegistrationComponent } from './user/registration/registration.component';
import { LoginComponent } from './user/login/login.component';
import { HomeComponent } from './home/home.component';

import { ClientSignUpComponent } from './client-signup/client-signup.component';
import { ClientLoginComponent } from './client-login/client-login.component';
import { ClientDashboardComponent } from './client/dashboard/dashboard.component';
import { VenueDetailsComponent } from './client/venuedetails/venuedetails.component';
import { FetchVenueDetailsComponent } from './client/fetchvenue/fetchvenue.component';

import { AddVenueComponent } from './client/addvenue/addvenue.component';

import { ClientFacilitiesListComponent } from './client/facilities/facilitieslist.component';
import { AddClientFacilities } from './client/addcfacilities/addcfacilities.component';
import { AddRoomsComponent } from './client/addrooms/addrooms.component';
import { ClientRoomsListComponent } from './client/rooms/rooms.component';

import { MySpaceListComponent } from './client/myspace/myspace.component';
import { AddMySpaceComponent } from './client/addmyspace/addmyspace.component';

import { BusinessHoursComponent } from './client/businesshours/businesshours.component';
import { AddBusinessHoursComponent } from './client/addbusinesshours/addbusinesshours.component';

import { FileUploadComponent } from './client/file-upload/file-upload.component';
import { GeoLocationComponent } from './client/geolocation/geolocation.component';
import { FetchGeoLocationComponent } from './client/fetchgeolocation/fetchgeolocation.component';

import { BookingsComponent } from './client/bookings/bookings.component';

import { VenueComponent } from './venue/venue.component';
import { ManageSpaceComponent } from './managespace/managespace.component';

import { OrganisationsComponent } from './org-home/organisations.component';
import { OrgRegistrationComponent } from './org-register/org-register.component';
import { OrgLoginComponent } from './org-login/org-login.component';
import { OrgDashboardComponent } from './organisation/dashboard/org-dashboard.component';
import { OrgProfileComponent } from './organisation/profile/profile.component';
import { OrgDetailsComponent } from './organisation/orgdetails/orgdetails.component';
import { OrgBookingsComponent } from './organisation/bookings/bookings.component';
import { BookingDetailsComponent } from './organisation/bookingdetails/bookingdetails.component';
import { myinfoComponent } from './organisation/myinfo/myinfo.component';

import { AdminLoginComponent } from './admin-login/admin-login.component';
import { AdminDashboardComponent } from './admin/dashboard/admin-dashboard.component';
import { AdminFacilitiesComponent } from './admin/facilities/facilities.component'; 
import { AdminAddFacilitiesComponent } from './admin/addfacilities/addfacilities.component';
import { CateringFacilitiesComponent } from './admin/cateringfacilities/cateringfacilities.component';
import { AddCateringFacilitiesComponent } from './admin/addcateringfacilities/addcateringfacilities.component';

import { VenueTypeListComponent } from './admin/venuetypes/venuetypes_listing/venuetypes_listing.component';
import { AddVenueTypeComponent } from './admin/venuetypes/venuetypes_add/venuetypes_add.component';

import { VenueHallOptionsComponent } from './admin/venue_halloptions/venue-halloptions.component';
import { AddVenueTypeOptionsComponent } from './admin/addvenue_halloptions/addvenue_halloptions.component';

import {SiteLayoutComponent} from './_Layouts/site-layout/site-layout.component';
import {ClientLayoutComponent} from './_Layouts/client-layout/client-layout.component';
import {AdminLayoutComponent} from './_Layouts/admin-layout/admin-layout.component';
import { OrgLayoutComponent } from './_Layouts/org-layout/org-layout.component';

import { VenuesListComponent } from './venueslist/venueslist.component';
import { VenueDetailComponent } from './venuedetails/venuedetails.component';

import { LoginModalComponent } from './login-modal/login-modal.component';
import { ShoppingCartComponent } from './shopping/shopping-cart/shopping-cart.component';
import { MyCartComponent } from './mycart/mycart.component';

import { UploadComponent } from './organisation/upload/upload.component';

import { ContactFormComponent } from './contact-form/contact-form.component';

import { ForgotPasswordComponent } from './forgot-password/forgot-password.component';
import { ResetPasswordComponent } from './reset-password/reset-password.component';

const routes: Routes = [
//site routes goes here 
{
  path: '',
  component: SiteLayoutComponent,
  children: [
    {path:'',component:HomeComponent, pathMatch:'full'},
    {path: 'venueslist/:vid/:cid/:lid', component: VenuesListComponent },
    {path: 'venuedetail/:cid', component: VenueDetailComponent },    
    {path:'clientsignup',component:ClientSignUpComponent},
    {path:'clientlogin',component:ClientLoginComponent},
    {path: 'organisations',component:OrganisationsComponent, pathMatch: 'full'},
    {path: 'venue',component:VenueComponent, pathMatch: 'full'},
    {path: 'managespace',component:ManageSpaceComponent, pathMatch: 'full'},
    {path: 'shoppingcart', component: ShoppingCartComponent },
    {path: 'mycart', component: MyCartComponent },
    {path: 'contact', component: ContactFormComponent },
    {path: 'forgotpassword', component: ForgotPasswordComponent },
    {path: 'resetpassword/:uid/:token', component: ResetPasswordComponent }
  ]
},
//client routes goes here 
{
  path: '',
  component: ClientLayoutComponent,
  children: [    
    { path: 'client/dashboard', component: ClientDashboardComponent, pathMatch: 'full' } ,
    { path: 'client/venuedetails', component: VenueDetailsComponent },
    { path: 'client/venuedetails/edit/:id', component: VenueDetailsComponent },
    { path: 'client/fetchvenue', component: FetchVenueDetailsComponent },
    { path: 'client/addvenue', component: AddVenueComponent },
    { path: 'client/addvenue/edit/:id', component: AddVenueComponent },    
    { path: 'client/cfacilities', component: ClientFacilitiesListComponent },
    { path: 'client/addcfacilities', component: AddClientFacilities },
    { path: 'client/rooms', component: ClientRoomsListComponent },    
    { path: 'client/addrooms', component: AddRoomsComponent },
    { path: 'client/addrooms/Edit/:id',component:AddRoomsComponent},
    { path: 'client/myspace', component: MySpaceListComponent },
    { path: 'client/addmyspace', component: AddMySpaceComponent },
    { path: 'client/addmyspace/edit/:id', component: AddMySpaceComponent },
    { path: 'client/businesshours', component: BusinessHoursComponent },
    { path: 'client/addbusinesshours', component: AddBusinessHoursComponent },
    { path: 'client/fileupload', component: FileUploadComponent },
    { path: 'client/geolocation', component: GeoLocationComponent },
    { path: 'client/geolocation/edit/:id', component: GeoLocationComponent },    
    { path: 'client/fetchgeolocation', component: FetchGeoLocationComponent },
    { path: 'client/bookings', component: BookingsComponent }    

  ]
},
//admin routes goes here 
{
  path: '',
  component: AdminLayoutComponent,
  children: [
    {path: 'admin/dashboard', component: AdminDashboardComponent, canActivate: [AuthGuard], pathMatch: 'full' },
    {path: 'admin/venuetypes',component:VenueTypeListComponent},
    {path: 'admin/addvenuetypes',component:AddVenueTypeComponent},
    {path: 'admin/addvenuetypes/edit/:id',component:AddVenueTypeComponent},
    {path: 'admin/facilities',component:AdminFacilitiesComponent},
    {path: 'admin/addfacilities',component:AdminAddFacilitiesComponent},
    {path: 'admin/addfacilities/edit/:id',component:AdminAddFacilitiesComponent},
    {path: 'admin/cateringfacilities',component:CateringFacilitiesComponent},
    {path: 'admin/addcateringfacilities',component:AddCateringFacilitiesComponent},
    {path: 'admin/addcateringfacilities/edit/:id',component:AddCateringFacilitiesComponent},
    {path: 'admin/venuehalloptions',component:VenueHallOptionsComponent},
    {path: 'admin/addvenuehalloptions',component:AddVenueTypeOptionsComponent},
    {path: 'admin/addvenuehalloptions/edit/:id',component:AddVenueTypeOptionsComponent},    
  ]
},
//organisation routes goes here 
{
  path: '',
  component: OrgLayoutComponent,
  children: [
    {path: 'organisation/OrgDashboard', component:OrgDashboardComponent , canActivate: [AuthGuard], pathMatch: 'full' },   
    {path: 'organisation/myinfo', component:myinfoComponent,canActivate: [AuthGuard], pathMatch: 'full'},   
    {path: 'organisation/profile', component:OrgProfileComponent , canActivate: [AuthGuard], pathMatch: 'full' },
    {path: 'organisation/orgdetails', component:OrgDetailsComponent , canActivate: [AuthGuard], pathMatch: 'full' },
    {path: 'organisation/bookings', component:OrgBookingsComponent , canActivate: [AuthGuard], pathMatch: 'full' },
    {path: 'organisation/bookingdetails/:id/:cid/:bdate', component:BookingDetailsComponent , canActivate: [AuthGuard], pathMatch: 'full' },
    {path: 'organisation/upload', component:UploadComponent}    
  ]  
},

//no layout routes
{path: 'admin',component:AdminLoginComponent, pathMatch: 'full'},
{path:'orgregister',component:OrgRegistrationComponent},
{path:'orglogin',component:OrgLoginComponent},
//{path: 'OrgDashboard',component:OrgDashboardComponent},
{path: 'loginmodal',component:LoginModalComponent},
{ path: '**', redirectTo: '' }

// {path:'',redirectTo:'/user/login',pathMatch:'full'},  
  // {
  //   path: 'user', component: UserComponent,
  //   children: [
  //     { path: 'registration', component: RegistrationComponent },
  //     { path: 'login', component: LoginComponent }
  //   ]
  // },
  //{path:'home',component:HomeComponent,canActivate:[AuthGuard]},  
 // {path: 'Dashboard',component:ClientDashboardComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
