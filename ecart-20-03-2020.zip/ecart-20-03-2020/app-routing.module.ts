import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { HomeComponent } from './components/home/home.component';
import { ShoppingCartComponent } from './components/shopping-cart/shopping-cart.component';

//import { DashboardComponent } from './admin/dashboard/dashboard.component'; 
import { ProductFormComponent } from './admin/product-form/product-form.component';
import { AdminOrdersComponent } from './admin/admin-orders/admin-orders.component';
import { AdminProductsComponent } from './admin/admin-products/admin-products.component';

import { ProductEditComponent } from './components/product-edit/product-edit.component';

import { AuthGuardService } from './services/auth-guard.service';

import { AdminBooksComponent } from './admin/admin-books/admin-books.component';
import { BooksFormComponent } from './admin/books-form/books-form.component';
import { BookEditComponent } from './admin/books-edit/books-edit.component';

import { CheckOutComponent } from './components/check-out/check-out.component';

import { SignInComponent } from './components/sign-in/sign-in.component';
import { SignUpComponent } from './components/sign-up/sign-up.component';
import { ForgotPasswordComponent } from './components/forgot-password/forgot-password.component';
import { VerifyEmailComponent } from './components/verify-email/verify-email.component';
import { DashboardComponent } from './components/dashboard/dashboard.component';

import { MyOrdersComponent } from './components/my-orders/my-orders.component';

import { ListOrderViewComponent } from './components/list-order-view/list-order-view.component';

// Import canActivate guard services
import { AuthGuard } from "../app/shared/guard/auth.guard";
import { SecureInnerPagesGuard } from "./shared/guard/secure-inner-pages.guard";

const routes: Routes = [
  {path: '', component: HomeComponent, data: {depth: 1}},
  {path: 'components/shopping-cart', 
  component: ShoppingCartComponent, data: {depth: 2}},
  {
    path: 'components/check-out', component: CheckOutComponent, data: {depth: 3},  canActivate:[AuthGuardService]
    
  },

  { 
    path:'admin/products/new', 
    component: ProductFormComponent,data: {depth: 5}
  },
  {
    path:'admin/products/:id', 
    component: ProductEditComponent, data: {depth: 6},
    canActivate:[AuthGuardService] 
  },
  {
    path:'admin/products', 
    component: AdminProductsComponent, data: {depth: 7}
  }, 

  {path: 'admin/dashboard', component: DashboardComponent, pathMatch: 'full' },
  {
    path:'admin/books', 
    component: AdminBooksComponent, data: {depth: 7}
  }, 
  { 
    path:'admin/books/new', 
    component: BooksFormComponent,data: {depth: 5}
  },
  {
    path:'admin/books/:id', 
    component: BookEditComponent, data: {depth: 6} 
  },
 
  { path: 'sign-in', component: SignInComponent, canActivate: [SecureInnerPagesGuard]},
  { path: 'register-user', component: SignUpComponent, canActivate: [SecureInnerPagesGuard]},
  { path: 'dashboard', component: DashboardComponent, canActivate: [AuthGuard] },
  { path: 'forgot-password', component: ForgotPasswordComponent, canActivate: [SecureInnerPagesGuard] },
  { path: 'verify-email-address', component: VerifyEmailComponent, canActivate: [SecureInnerPagesGuard] },
  { path: 'myorder', component: MyOrdersComponent }


];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
