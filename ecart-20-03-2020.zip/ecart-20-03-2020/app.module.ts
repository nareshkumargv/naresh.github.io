import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgModule } from '@angular/core';
import { MaterialModule } from './material';
// Firebase services + enviorment module
import { AngularFireModule } from "@angular/fire";
import { AngularFireDatabaseModule } from '@angular/fire/database';
import { AngularFireAuthModule } from "@angular/fire/auth";
import { AngularFirestoreModule } from '@angular/fire/firestore';
import { environment } from '../environments/environment';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { MDBBootstrapModule } from 'angular-bootstrap-md';
import { FormsModule } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms'; 
import { HomeComponent } from './components/home/home.component';

import { BsNavbarComponent } from './components/bs-navbar/bs-navbar.component';
import { BsFooterComponent } from './components/bs-footer/bs-footer.component';

import { DefaultComponent } from './components/default/default.component';
import { ProductCardComponent } from './components/product-card/product-card.component';
import { ProductQuantityComponent } from './components/product-quantity/product-quantity.component';
import { ProductFilterComponent } from './products/product-filter/product-filter.component';
import { MatDialogComponent } from './components/mat-dialog/mat-dialog.component'; 
import { ShoppingCartComponent } from './components/shopping-cart/shopping-cart.component';
import { ProductEditComponent } from './components/product-edit/product-edit.component';

import { CategoryService } from './services/category.service'; 
import { ProductService } from './services/product.service'; 
import { UserService } from './services/user.service'; 
import { ShoppingCartService } from './services/shopping-cart.service';
import { OrderService } from './services/order.service'; 
import { PriceService } from './services/price.service'; 
import { GenderService } from './services/gender.service'; 
import { MatDialogService } from './services/mat-dialog.service';
import { ShapeService } from './services/shape.service'; 
import { BandMakeService } from './services/band-make.service';
import { BandService } from './services/band.service'; 
import { DialService } from './services/dial.service';

import { BooksService } from './services/books.service';

import { AuthService } from './services/auth.service'; 
import { AuthGuardService } from './services/auth-guard.service';
//import { AdminAuthGuardService } from './services/admin-auth-guard.service';

//import { DashboardComponent } from './admin/dashboard/dashboard.component'; 
import { ProductFormComponent } from './admin/product-form/product-form.component';
import { AdminOrdersComponent } from './admin/admin-orders/admin-orders.component';
import { AdminProductsComponent } from './admin/admin-products/admin-products.component';

import { AdminBooksComponent } from './admin/admin-books/admin-books.component';
import { BooksFormComponent } from './admin/books-form/books-form.component';
import { BookEditComponent } from './admin/books-edit/books-edit.component';

import { CheckOutComponent } from './components/check-out/check-out.component';
import { ShoppingCartSummaryComponent } from './components/shopping-cart-summary/shopping-cart-summary.component';
import { SignInComponent } from './components/sign-in/sign-in.component';
import { SignUpComponent } from './components/sign-up/sign-up.component';
import { ForgotPasswordComponent } from './components/forgot-password/forgot-password.component';
import { VerifyEmailComponent } from './components/verify-email/verify-email.component';
import { DashboardComponent } from './components/dashboard/dashboard.component';

import { MyOrdersComponent } from './components/my-orders/my-orders.component';

import { ListOrderViewComponent } from './components/list-order-view/list-order-view.component';

@NgModule({
  declarations: [
    AppComponent,
    BsNavbarComponent,
    BsFooterComponent,
    HomeComponent,
    ShoppingCartComponent,
    DefaultComponent,
    ProductCardComponent,
    ProductQuantityComponent,
    ProductFilterComponent,MatDialogComponent, DashboardComponent,ProductEditComponent,
    ProductFormComponent,AdminOrdersComponent,AdminProductsComponent,ListOrderViewComponent,
    AdminBooksComponent,BooksFormComponent,BookEditComponent,
    CheckOutComponent,ShoppingCartSummaryComponent, 
    SignInComponent, SignUpComponent, ForgotPasswordComponent, VerifyEmailComponent,
    MyOrdersComponent
  ],
  imports: [
    BrowserModule,MaterialModule,FormsModule,ReactiveFormsModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    MDBBootstrapModule.forRoot(),
    AngularFireModule.initializeApp(environment.firebase),
    AngularFireDatabaseModule,
    AngularFireAuthModule,
    AngularFirestoreModule
  ],
  providers: [CategoryService, AuthService, AuthGuardService, UserService,
    ProductService, ShoppingCartService,OrderService,
    GenderService, PriceService, MatDialogService, ShapeService, BandMakeService,
    DialService, BandService, BooksService],
    entryComponents: [MatDialogComponent],
  bootstrap: [AppComponent]
})
export class AppModule { }
