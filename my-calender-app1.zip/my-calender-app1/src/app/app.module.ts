import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import {FormsModule} from '@angular/forms';

import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { Routes, RouterModule } from '@angular/router';

import { AppComponent } from './app.component';
import {CalendarModule} from 'primeng/calendar';
import {ScheduleModule} from 'primeng/schedule';

import { CalendarComponent } from './calendar/calendar.component';
import { ScheduleComponent } from './schedule/schedule.component';

import { FullCalendarModule } from 'ng-fullcalendar';
import { EventSesrvice } from './event.service';

@NgModule({
  declarations: [
    AppComponent,
    CalendarComponent,ScheduleComponent    
  ],
  imports: [
    BrowserModule,FormsModule,BrowserAnimationsModule,CalendarModule,ScheduleModule,FullCalendarModule,
    RouterModule.forRoot([
      { path: '', redirectTo: 'app-root', pathMatch: 'full' },
      { path: 'calendar', component: CalendarComponent },
      { path: '**', redirectTo: 'app-root' }
    ])
  ],
  providers: [EventSesrvice],
  bootstrap: [AppComponent]
})
export class AppModule { }
