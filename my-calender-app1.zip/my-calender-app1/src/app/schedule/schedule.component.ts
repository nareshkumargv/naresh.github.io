import { Component, OnInit, ViewChild } from '@angular/core';

import { CalendarComponent } from 'ng-fullcalendar';
import { Options } from 'fullcalendar';

import { EventSesrvice } from '../event.service'

@Component({
  selector: 'app-schedule',
  templateUrl: './schedule.component.html',
  styleUrls: ['./schedule.component.css']
})
export class ScheduleComponent implements OnInit {
  calendarOptions: Options;
  displayEvent: any;

  nHours:any;
  nDays:any;
  tothrprice:any;

  hourprice = 200;

  @ViewChild(CalendarComponent) ucCalendar: CalendarComponent;
  
  constructor(protected eventService: EventSesrvice) { }
 
  ngOnInit() {
    this.eventService.getEvents().subscribe(data => {
      this.calendarOptions = {
        defaultView: 'agendaWeek',        
        allDaySlot:false,
        //businessHours:true,
       businessHours:[{
          dow: [ 0, 1, 2, 3, 4, 5, 6 ], // sunday - saturaday
          start: '09:00', // a start time (9am in this example)
         end: '21:00', // an end time (9pm in this example)
       }],                
        editable: true,
        selectable: true,
        selectHelper: true,               
        eventLimit: true,        
        header: {
          left: 'prev,next today',
          center: 'title',
          right: 'month,agendaWeek,agendaDay,listMonth'
        },
        events:[{
          constraint: 'businessHours'
        }], 
        timezone: 'local',
        height: "auto",
        
      };
    });
  }

  clickButton(model: any) {
    //console.log(model);
    this.displayEvent = model;
  }
  eventClick(model: any) {
    model = {
      event: {
        id: model.event.id,
        start: model.event.start,
        end: model.event.end,
        title: model.event.title,
        allDay: model.event.allDay
        // other params
      },
      duration: {}
    }
    this.displayEvent = model;
  }
  updateEvent(model: any) {
    model = {
      event: {
        id: model.event.id,
        start: model.event.start,
        end: model.event.end,
        title: model.event.title
        // other params
      },
      duration: {
        _data: model.duration._data
      }
    }
    this.displayEvent = model;
  }
  

  select(start, end, allDay) {
   // start = new Date();
    let startdate = start.start._d;
    let enddate = start.end._d;
    console.log(startdate);
    //console.log(enddate);
    
    let sdate = new Date(startdate);
    let edate = new Date(enddate);
    
    let sday =sdate.getDate();
    console.log(sday);
    let smonth = sdate.getMonth()+1;     
    let syear =sdate.getFullYear();

    let sthrs = sdate.getHours();
    //console.log(sthrs);
    let stmins = sdate.getMinutes();
    let stsecs = sdate.getSeconds()

    let eday =edate.getDate();
    let emonth = edate.getMonth()+1;     
    let eyear =edate.getFullYear();

    let ethrs = edate.getHours();
    //console.log(sthrs);
    let etmins = edate.getMinutes();
    let etsecs = edate.getSeconds();

    let psdate = (sday +'-'+ smonth+'-'+syear +' to '+ eday +'-'+ emonth+'-'+eyear);
    console.log(psdate);

    let stime = (sthrs +':'+ stmins +':'+stsecs);
    console.log(stime);

    let etime = (ethrs +':'+ etmins +':'+etsecs);
    console.log(etime);

    let tothrs = (stime +' - '+ etime)
    console.log(tothrs);

    let compldate = (sday +'-'+ smonth+'-'+syear +' - '+ sthrs +':'+ stmins +':'+stsecs +' to '+ eday +'-'+ emonth+'-'+eyear +' - '+ ethrs +':'+ etmins +':'+etsecs);
    console.log(compldate);

    let noofDays = Math.abs(eday - sday);    
    this.nDays = noofDays;
    console.log(this.nDays + ' Day(s)');

    let timeduration = (ethrs - sthrs );
    console.log(timeduration + ' Hr(s)'); 
    this.nHours = timeduration;    
    console.log(this.nHours);

    this.tothrprice = this.nHours * this.hourprice;
    console.log(this.tothrprice);

    let Bhrs = (noofDays + ' Day(s)' + '--' + timeduration + ' Hr(s)' )          

    let title = prompt('Event Title:');

  if (title) {
    this.ucCalendar.fullCalendar('renderEvent',
      {
        title:title,
        start:startdate,
        end:enddate,
        allDay: allDay,
        editable: true,
        eventDurationEditable: true,
        eventStartEditable: true,
        color: 'red',       
      },
      true
    );
  }
  this.ucCalendar.fullCalendar('unselect');
  this.displayEvent = (+'  '+ compldate +' - '+ Bhrs);

  }

}
