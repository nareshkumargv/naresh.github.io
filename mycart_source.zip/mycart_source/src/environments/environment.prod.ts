export const environment = {
  production: true,
  firebaseConfig: {
    apiKey: "AIzaSyDUagzMGqXJ6wMQtoN1ujDiz1i1mLwGNzc",
    authDomain: "mystore-ff1f3.firebaseapp.com",
    databaseURL: "https://mystore-ff1f3.firebaseio.com",
    projectId: "mystore-ff1f3",
    storageBucket: "mystore-ff1f3.appspot.com",
    messagingSenderId: "1061940225348",
    appId: "1:1061940225348:web:442e7d93121c9fa585e311"
  }
};
