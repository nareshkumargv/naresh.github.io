import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-login',
  templateUrl: './admin-login.component.html',
  styleUrls: []
})
export class AdminLoginComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}