import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AppComponent } from './app.component';

import { DashboardComponent } from './client/dashboard/dashboard.component';
import { AdminDashboardComponent } from './admin/dashboard/dashboard.component';

import { ClientLayoutComponent } from './_layout/client-layout/client-layout.component';
import { AdminLayoutComponent } from './_layout/admin-layout/admin-layout.component';
import { SiteLayoutComponent } from './_layout/site-layout/site-layout.component';

import { HomeComponent } from './home/home.component';
import { AdminLoginComponent } from './admin-login/admin-login.component';
import { AboutComponent } from './about/about.component';

import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
@NgModule({
  declarations: [
    AppComponent,
    DashboardComponent,
    AdminDashboardComponent,
    ClientLayoutComponent,
    AdminLayoutComponent,
    SiteLayoutComponent,
    HomeComponent,
    AdminLoginComponent,
    AboutComponent
  ],
  imports: [
    BrowserModule,FontAwesomeModule,    
    RouterModule.forRoot([
    //  { path: 'admin', component: AdminDashboardComponent },

    //site routes goes here 
    { 
      path: '', 
      component: SiteLayoutComponent,
      children: [
        { path: '', component: HomeComponent, pathMatch: 'full'},
        { path: 'about', component: AboutComponent }
      ]
     },

      //client routes goes here 
      { 
        path: '', 
        component: ClientLayoutComponent,
        children: [
          { path: 'client', component: DashboardComponent, pathMatch: 'full'}
        ]
       },

       //admin routes goes here 
      { 
         path: '', 
         component: AdminLayoutComponent,
         children: [
           { path: 'admin/dashboard', component: AdminDashboardComponent, pathMatch: 'full'}
         ]
      },

       //no layout routes
      { path: 'admin', component: AdminLoginComponent},
      { path: '**', redirectTo: '' }      



  ])
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
