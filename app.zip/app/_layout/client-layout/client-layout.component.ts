import { Component, ViewEncapsulation, OnInit } from '@angular/core';

@Component({
  selector: 'app-client-layout',
  templateUrl: './client-layout.component.html',
  styleUrls: ['./client-layout.component.css'],
  //encapsulation: ViewEncapsulation.Native
  //encapsulation: ViewEncapsulation.ShadowDom
})
export class ClientLayoutComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
