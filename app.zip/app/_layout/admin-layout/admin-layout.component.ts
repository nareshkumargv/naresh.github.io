import { Component, ViewEncapsulation, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-layout',
  templateUrl: './admin-layout.component.html',
  styleUrls: ['./admin-layout.component.css'],
  //encapsulation: ViewEncapsulation.Native
  //encapsulation: ViewEncapsulation.ShadowDom
  //encapsulation: ViewEncapsulation.Emulated
  encapsulation: ViewEncapsulation.None
})
export class AdminLayoutComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
