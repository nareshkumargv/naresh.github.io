import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { DashboardComponent } from './client/dashboard/dashboard.component';
import { AdminDashboardComponent } from './admin/dashboard/dashboard.component';

import { ClientLayoutComponent } from './_layout/client-layout/client-layout.component';
import { AdminLayoutComponent } from './_layout/admin-layout/admin-layout.component';

const routes: Routes = [

   //client routes goes here 
   { 
    path: '', 
    component: ClientLayoutComponent,
    children: [
      { path: 'client/dashboard', component: DashboardComponent, pathMatch: 'full'}
    ]
   },

//admin routes goes here 
{ 
  path: '', 
  component: AdminLayoutComponent,
  children: [
    { path: 'admin/dashboard', component: AdminDashboardComponent, pathMatch: 'full'}
  ]
 }



];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
