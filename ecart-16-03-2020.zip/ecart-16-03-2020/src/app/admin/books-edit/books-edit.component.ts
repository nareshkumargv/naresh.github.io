import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { take } from 'rxjs/operators'
import { Subject } from 'rxjs';

@Component({
  selector: 'app-book-edit',
  templateUrl: './books-edit.component.html',
  styleUrls: []
}) 
export class BookEditComponent implements OnInit {

    ngOnInit() {
    }
}