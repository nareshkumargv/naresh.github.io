export interface School {
    key: string;
    title: string;
    boardkey: string,
    statekey: string;
    citykey: string;
    imageUrl: string;
    address: string;
    description: string; 
}