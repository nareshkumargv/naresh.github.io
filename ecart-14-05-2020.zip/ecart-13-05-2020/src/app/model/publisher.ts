export class Publisher {
    key: string;
    publishername: string;   
 }