//import { Product } from './product';
import {Books} from './books';

export class ShoppingCartItem {
    key: string;
    title: string;
    //imageUrl: string;
    cover:string;
    price: number;

    constructor(
        public product: Books,        
        public quantity: number
        ) {

}
    get totalPrice() {
        return this.product.price * this.quantity; 
        
    }
} 


// export class ShoppingCartItem {
//     key: string;
//     title: string;
//     imageUrl: string;
//     price: number;
//     quantity: number;

//     constructor(init?: Partial<ShoppingCartItem>) {
//             Object.assign(this, init);
//     }
 
     // constructor(public product: Product, public quantity: number) {}

//     get totalPrice() {
//         return this.price * this.quantity; 
//     }
// }