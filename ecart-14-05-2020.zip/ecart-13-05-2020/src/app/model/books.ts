export interface Books {
    key: string;
    isbn:string;    
    title: string; 
    schoolkey:string;
    classkey:string;
    languagekey:string;
    categorykey:string;
    publisherkey:string;
    price: number;
    synopsis: string; 
    imageUrl : string;
}

