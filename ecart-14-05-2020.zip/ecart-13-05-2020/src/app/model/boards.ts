export class Boards {
    key: string;
    boardname: string;   
 } 