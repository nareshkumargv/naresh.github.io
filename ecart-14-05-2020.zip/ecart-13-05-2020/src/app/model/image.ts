export class Image {
    key: string;
    caption: string; 
    category:string;
    imageUrl:string;    
 }