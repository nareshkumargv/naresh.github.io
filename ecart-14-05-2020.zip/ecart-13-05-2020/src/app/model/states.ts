export class States {
    key: string;
    statename: string;   
 }