export interface ClassBooks {
    key: string;
    isbn:string;    
    title: string;    
    price: number;
    imageUrl : string;
    synopsis: string;
    schoolkey:string;
    classkey:string;
    languagekey:string;
    categorykey:string;
    publisherkey:string;
}