export class Class {
    key: string;
    classname: number;   
 }