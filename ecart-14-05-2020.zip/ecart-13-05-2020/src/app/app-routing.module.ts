import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AdminLayoutComponent } from './_layout/admin-layout/admin-layout.component';
import { UserLayoutComponent } from './_layout/user-layout/user-layout.component';
import { SiteLayoutComponent } from './_layout/site-layout/site-layout.component';

import { HomeComponent } from './components/home/home.component';
import { AcademicsComponent } from './components/Academics/Academics.component';
import { ShoppingCartComponent } from './components/shopping-cart/shopping-cart.component';
import { UserCartComponent } from './components/user-cart/user-cart.component';

import { AdminDashboardComponent } from './admin/admin-dashboard/dashboard.component'; 
import { ProductFormComponent } from './admin/product-form/product-form.component';
import { AdminOrdersComponent } from './admin/admin-orders/admin-orders.component';
import { AdminOrderDetailsComponent } from './admin/admin-orderdetails/admin-orderdetails.component';
import { AdminProductsComponent } from './admin/admin-products/admin-products.component';

import { ProductEditComponent } from './components/product-edit/product-edit.component';

import { AuthGuardService } from './services/auth-guard.service';
import { AdminAuthGuardService } from './services/admin-auth-guard.service';

import { AdminLoginComponent } from './admin/admin-login/admin-login.component';
import { AdminBooksComponent } from './admin/admin-books/admin-books.component';
import { BooksFormComponent } from './admin/books-form/books-form.component';
import { BookEditComponent } from './admin/books-edit/books-edit.component';

import { AdminClassBooksComponent } from './admin/admin-classbooks/admin-classbooks.component';
import { ClassBooksFormComponent } from './admin/classbooks-form/classbooks-form.component';
import { AdminBoardComponent } from './admin/admin-boards/admin-boards.component';
import { BoardsFormComponent } from './admin/boards-form/boards-form.component';
import { AdminStateComponent } from './admin/admin-states/admin-states.component';
import { StatesFormComponent } from './admin/states-form/states-form.component';
import { AdminCitiesComponent } from './admin/admin-cities/admin-cities.component';
import { CitiesFormComponent } from './admin/cities-form/cities-form.component';
import { AdminCategoriesComponent } from './admin/admin-categories/admin-categories.component';
import { CategoriesFormComponent } from './admin/categories-form/categories-form.component';
import { AdminSchoolsComponent } from './admin/admin-schools/admin-schools.component';
import { SchoolsFormComponent } from './admin/schools-form/schools-form.component';
import { AdminClassComponent } from './admin/admin-class/admin-class.component';
import { ClassFormComponent } from './admin/class-form/class-form.component';
import { AdminLanguageComponent } from './admin/admin-languages/admin-languages.component';
import { LanguagesFormComponent } from './admin/languages-form/languages-form.component';
import { AdminPublishersComponent } from './admin/admin-publishers/admin-publishers.component';
import { PublishersFormComponent } from './admin/publishers-form/publishers-form.component';

import { SignInComponent } from './components/sign-in/sign-in.component';
import { SignUpComponent } from './components/sign-up/sign-up.component';
import { ForgotPasswordComponent } from './components/forgot-password/forgot-password.component';
import { VerifyEmailComponent } from './components/verify-email/verify-email.component';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { ProductDetailsComponent } from './product-details/product-details.component';
import { PopupLoginComponent } from './components/popup-login/popup-login.component';
import { SearchComponent } from './components/search/search.component';
import { SchoolsListComponent } from './components/schoolslist/schoolslist.component';
import { SchoolsDetailsComponent } from './components/school-details/school-details.component';
import { MyOrdersComponent } from './components/my-orders/my-orders.component';
import { OrderDetailsComponent } from './components/order-details/order-details.component';
import { CheckOutComponent } from './components/check-out/check-out.component';

import { ImageUploadComponent } from './components/image-upload/image-upload.component';


// Import canActivate guard services
//import { AuthGuard } from "../app/shared/guard/auth.guard";
import { SecureInnerPagesGuard } from "./shared/guard/secure-inner-pages.guard";

const routes: Routes = [
//site routes goes here 
{ 
  path: '', 
  component: SiteLayoutComponent,
  children: [   
    {path: '', component: HomeComponent, data: {depth: 1}},
    { path: 'academics', component: AcademicsComponent },
    { path: 'components/shopping-cart', component: ShoppingCartComponent, data: {depth: 2}},
    { path: 'components/user-cart', component: UserCartComponent, data: {depth: 2}},    
    //{ path: 'components/check-out', component: CheckOutComponent, canActivate:[AuthGuardService]},
    { path: 'components/check-out/:schoolid/:sname/:sno/:selectedclass/:selectedlanguage/:gtotal', component: CheckOutComponent, canActivate:[AuthGuardService]},
    { path: 'productdetails/:key', component: ProductDetailsComponent}, 
    { path: 'sign-in', component: SignInComponent, canActivate: [SecureInnerPagesGuard]},
    { path: 'register-user', component: SignUpComponent, canActivate: [SecureInnerPagesGuard]},
    { path: 'forgot-password', component: ForgotPasswordComponent, canActivate: [SecureInnerPagesGuard] },
    { path: 'verify-email-address', component: VerifyEmailComponent, canActivate: [SecureInnerPagesGuard] },
    { path: 'popuplogin', component: PopupLoginComponent, canActivate: [SecureInnerPagesGuard]},
    { path: 'schoolslist/:bid/:sid/:cid', component: SchoolsListComponent },
    { path: 'school-details/:key/:cid/:sid', component: SchoolsDetailsComponent }   
  ]
},
//admin routes goes here 
{ 
  path: '', 
  component: AdminLayoutComponent,
  children: [
    { path:'admin/admin-dashboard', component: AdminDashboardComponent, pathMatch: 'full'},
    { path:'admin/products/new', component: ProductFormComponent,data: {depth: 5}},
    { path:'admin/products/:id', component: ProductEditComponent, data: {depth: 6}, canActivate:[AuthGuardService, AdminAuthGuardService] },
    { path:'admin/products', component: AdminProductsComponent, data: {depth: 7}}, 
    { path:'admin/boards', component: AdminBoardComponent, data: {depth: 7}}, 
    { path:'admin/boards/new', component: BoardsFormComponent,data: {depth: 5}},
    { path:'admin/states', component: AdminStateComponent, data: {depth: 7}}, 
    { path:'admin/states/new', component: StatesFormComponent,data: {depth: 5}},
    { path:'admin/cities', component: AdminCitiesComponent, data: {depth: 7}}, 
    { path:'admin/cities/new', component: CitiesFormComponent,data: {depth: 5}}, 
    { path:'admin/categories', component: AdminCategoriesComponent, data: {depth: 7}}, 
    { path:'admin/categories/new', component: CategoriesFormComponent,data: {depth: 5}}, 
    { path:'admin/languages', component: AdminLanguageComponent, data: {depth: 7}}, 
    { path:'admin/languages/new', component: LanguagesFormComponent,data: {depth: 5}}, 
    { path:'admin/publishers', component: AdminPublishersComponent, data: {depth: 7}}, 
    { path:'admin/publishers/new', component: PublishersFormComponent,data: {depth: 5}}, 
    { path:'admin/schools', component: AdminSchoolsComponent, data: {depth: 7}}, 
    { path:'admin/schools/new', component: SchoolsFormComponent,data: {depth: 5}},   
    { path:'admin/class', component: AdminClassComponent, data: {depth: 7}}, 
    { path:'admin/class/new', component: ClassFormComponent,data: {depth: 5}}, 
    { path:'admin/books',component: AdminBooksComponent, data: {depth: 7}}, 
    { path:'admin/books/new', component: BooksFormComponent,data: {depth: 5}},
    { path:'admin/books/:id', component: BookEditComponent, data: {depth: 6}},  
    { path:'admin/classbooks', component: AdminClassBooksComponent, data: {depth: 7}}, 
    { path:'admin/classbooks/new', component: ClassBooksFormComponent,data: {depth: 5}},
    { path:'admin/orders', component: AdminOrdersComponent, data: {depth: 7}},
    { path:'admin/adminorder-details/:key', component: AdminOrderDetailsComponent, data: {depth: 7}},
  
  ]
 },
//user routes goes here 
{ 
  path: '', 
  component: UserLayoutComponent,
  children: [   
    //{ path: 'dashboard', component: DashboardComponent,pathMatch: 'full', canActivate: [AuthGuard] },
    { path: 'dashboard', component: DashboardComponent,pathMatch: 'full' },
    { path: 'myorders', component: MyOrdersComponent },
    { path: 'order-details/:key', component: OrderDetailsComponent },
  ]
},
//no layout routes
{path: 'admin',component:AdminLoginComponent, pathMatch: 'full'},
{path: 'search',component:SearchComponent, pathMatch: 'full'},
{path: 'ImageUpload',component:ImageUploadComponent, pathMatch: 'full'}

  // {path: '', component: HomeComponent, data: {depth: 1}},
  // { path: 'myorders', component: MyOrdersComponent },
  // { path: 'order-details/:key', component: OrderDetailsComponent },
  // { path: 'dashboard', component: DashboardComponent, canActivate: [AuthGuard] },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
