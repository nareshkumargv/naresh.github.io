import { Injectable } from '@angular/core';
import { AngularFireDatabase, AngularFireList, AngularFireObject } from '@angular/fire/database';
import { map } from 'rxjs/operators';
import { FirebaseFirestore } from '@angular/fire';

import { Books } from '../model/books';
 
@Injectable({
  providedIn: 'root'
})
export class BooksService { 
  dataSource: AngularFireList<Books>;
  itemRef : any; 
  items: Books[] = [];

  constructor(private db: AngularFireDatabase) {     
  }


  create(book:any) {
      console.log(book);
    this.db.list('/books').push(book); 
  } 

  // This code worked for me for retrieving keys from firebase
  getAll() { 
    this.itemRef =  this.db. list('/books').snapshotChanges().pipe(map(changes => {
      return changes.map(c => ({ key: c.payload.key, ...c.payload.val() }));
    }));
    return this.itemRef;
  }
 
  get(booksId) {
    return this.db.object('/books/' +booksId);
  }

  update(booksId, books) {
    return this.db.object('/books/' + booksId).update(books);
  }

  delete(booksId) {
    return this.db.object('/books/' + booksId).remove(); 
  }


}