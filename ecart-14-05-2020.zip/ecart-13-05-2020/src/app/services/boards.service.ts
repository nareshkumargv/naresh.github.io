import { Injectable } from '@angular/core';
import { AngularFireDatabase, AngularFireList, AngularFireObject } from '@angular/fire/database';
import { map } from 'rxjs/operators';
import { FirebaseFirestore } from '@angular/fire';

import { Boards } from '../model/boards';

@Injectable({
    providedIn: 'root'
  })
  export class BoardsService { 
  boards: AngularFireList<Boards>;
  itemRef : any;
  items: Boards[] = [];

  constructor(private db: AngularFireDatabase) {
    this.getboards();
  }

  getboards() {
    this.boards = this.db.list("boards");
    return this.boards;
    console.log(this.boards);
  }

  create(board:any) {
    console.log(board);
    this.boards.push(board);
  }

    // This code worked for me for retrieving keys from firebase
    getAll() { 
        this.itemRef =  this.db. list('/boards').snapshotChanges().pipe(map(changes => {
          return changes.map(c => ({ key: c.payload.key, ...c.payload.val() }));
        }));
        return this.itemRef;
      }

      get(boardsId) {
        return this.db.object('/boards/' +boardsId);
      }  

      update(boardsId, boards) {
        return this.db.object('/boards/' + boardsId).update(boards);
      }
    
      delete(boardsId) {
        return this.db.object('/boards/' + boardsId).remove(); 
      }

  }