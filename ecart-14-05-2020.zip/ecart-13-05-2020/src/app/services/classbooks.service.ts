import { Injectable } from '@angular/core';
import { AngularFireDatabase, AngularFireList, AngularFireObject } from '@angular/fire/database';
import { map } from 'rxjs/operators';
import { FirebaseFirestore } from '@angular/fire';

import { ClassBooks } from '../model/classbooks';
 
@Injectable({
  providedIn: 'root'
})
export class ClassBooksService { 
  dataSource: AngularFireList<ClassBooks>;
    itemRef : any;
 // dataSource: AngularFireList<Books>;
  items: ClassBooks[] = [];

  constructor(private db: AngularFireDatabase) {
   //   this.getclassbooks();
  }

  // getclassbooks() {
  //   this.classbooks = this.db.list("classbooks");
  //   return this.classbooks;
  // }

  create(classbook) {
    console.log(classbook);
    this.db.list('/classbooks').push(classbook);
  //  this.classbooks.push(classbook);
  } 

  // This code worked for me for retrieving keys from firebase
  getAll() { 
    this.itemRef =  this.db. list('/classbooks').snapshotChanges().pipe(map(changes => {
      return changes.map(c => ({ key: c.payload.key, ...c.payload.val() }));
    }));
    return this.itemRef;
  }
 
  get(classbooksId) {
    return this.db.object('/classbooks/' +classbooksId);
  }

  update(classbooksId, classbooks) {
    return this.db.object('/classbooks/' + classbooksId).update(classbooks);
  }

  delete(classbooksId) {
    return this.db.object('/classbooks/' + classbooksId).remove(); 
  }


}