import { Injectable } from '@angular/core';
import { AngularFireDatabase, AngularFireList, AngularFireObject } from '@angular/fire/database';
import { map } from 'rxjs/operators';
import { FirebaseFirestore } from '@angular/fire';

import { Category } from '../model/categories';

@Injectable({
    providedIn: 'root'
  })
  export class CategoriesService { 
    categories: AngularFireList<Category>;
    itemRef : any;
    items: Category[] = [];

    constructor(private db: AngularFireDatabase) {
        this.getcategories();
      }

      getcategories() {
        this.categories = this.db.list("categories");
        return this.categories;
        console.log(this.categories);
      }

      create(category:any) {
        console.log(category);
        this.categories.push(category);
      }

            // This code worked for me for retrieving keys from firebase
    getAll() { 
        this.itemRef =  this.db. list('/categories').snapshotChanges().pipe(map(changes => {
          return changes.map(c => ({ key: c.payload.key, ...c.payload.val() }));
        }));
        return this.itemRef;
    }

      get(categoryId) {
        return this.db.object('/categories/' +categoryId);
      }  

      update(categoryId, categories) {
        return this.db.object('/categories/' + categoryId).update(categories);
      }
    
      delete(categoryId) {
        return this.db.object('/categories/' + categoryId).remove(); 
      }


    }