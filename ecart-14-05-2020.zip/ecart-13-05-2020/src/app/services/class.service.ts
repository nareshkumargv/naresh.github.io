import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { AngularFireDatabase, AngularFireList, AngularFireObject } from '@angular/fire/database';
import { map } from 'rxjs/operators';
import { BehaviorSubject } from 'rxjs';
import { FirebaseFirestore } from '@angular/fire';


import { Class } from '../model/class';

@Injectable({
    providedIn: 'root'
  })
  export class ClassService { 
    classes: AngularFireList<Class>;
    itemRef : any;
    items: Class[] = [];

    onCustomerSelect: BehaviorSubject<any> = new BehaviorSubject<any>(null);    
    constructor(
        private http: HttpClient,
        private db: AngularFireDatabase) {
        this.getclasses();
    }

    getclasses() {
        this.classes = this.db.list("class");
        return this.classes;
        console.log(this.classes);
    }

    create(sclass:any) {
        console.log(sclass);
        this.classes.push(sclass);
    }

             // This code worked for me for retrieving keys from firebase
    getAll() { 
        this.itemRef =  this.db. list('/class').snapshotChanges().pipe(map(changes => {
          return changes.map(c => ({ key: c.payload.key, ...c.payload.val() }));
        }));
        return this.itemRef;
    }


    // get(classId) {
    //   console.log(classId);
    //   return this.db.object('/class/' +classId);
    // }  

    // public async get(classId) {    
    //     return this.db.object('/class/' +classId);       
    // }

    public async get(id: string) {    
        return this.db.object('/class/' +id);
    }



    update(classId, sclass) {
        return this.db.object('/class/' + classId).update(sclass);
    }
    
    delete(classId) {
        return this.db.object('/class/' + classId).remove(); 
    }



  }