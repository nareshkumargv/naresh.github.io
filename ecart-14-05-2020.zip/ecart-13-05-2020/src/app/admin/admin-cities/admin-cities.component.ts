import { Component, OnInit, OnDestroy, ViewChild } from '@angular/core';
import { ActivatedRoute} from '@angular/router';
import { Subscription } from 'rxjs';

import { MatTableDataSource } from '@angular/material/table';
import { MatDialogService } from 'src/app/services/mat-dialog.service';

import { Cities } from 'src/app/model/cities';
import { CitiesService } from 'src/app/services/cities.service';

@Component({
    selector: 'app-cities',
    templateUrl: './admin-cities.component.html',
    styleUrls: []
  })
  export class AdminCitiesComponent implements  OnInit, OnDestroy { 
    cities: Cities[];
    subscription: Subscription;
    items: Cities[] = [];
    itemCount: number;
    dude: any;
    id;

    listData: MatTableDataSource<any[]>;
    displayedColumns: string[] = ['cityname', 'edit', 'delete'];
    searchKey:string;

    constructor(private route: ActivatedRoute,
        private dialogService: MatDialogService,
        private citiesService:CitiesService) { 
          this.id = this.route.snapshot.paramMap.get('id');
    
          this.subscription = this.citiesService.getAll().subscribe(cities => {
            this.cities = cities;
            console.log(this.cities);
            });  
        }

        ngOnInit() {
            this.citiesService.getAll().subscribe(
              list=> {
                this.listData = new MatTableDataSource(list);
              //  this.listData.sort = this.sort;
              //  this.listData.paginator = this.paginator;
              }
            );
          }

          delete(key) {
            this.dialogService.openConfirmDialog('Are you sure to delete this record?')
            .afterClosed().subscribe(res => {
              if(res) {
                this.citiesService.delete(key);
              }
            }); 
          } 
 
    ngOnDestroy() {
        this.subscription.unsubscribe();
       }

}