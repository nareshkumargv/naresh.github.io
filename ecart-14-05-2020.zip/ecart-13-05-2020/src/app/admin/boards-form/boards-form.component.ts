import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { take } from 'rxjs/operators'

import {BoardsService } from 'src/app/services/boards.service';

@Component({
    selector: 'app-boards-form',
    templateUrl: './boards-form.component.html',
    styleUrls: []
  })

  export class BoardsFormComponent implements OnInit { 
    board = {};
    id;

    constructor(
      private route: ActivatedRoute,private router: Router,
      private boardsService: BoardsService) {
        this.id = this.route.snapshot.paramMap.get('id');
        console.log("Board ID", this.id);

        // Important line of code to get single board from firebase
        if(this.id) this.boardsService.get(this.id).valueChanges().
        pipe(take(1)).subscribe(p => this.board = p);
      }

      save(board) {
        console.log(board);
        if(this.id) this.boardsService.update(this.id, board)
        else 
        this.boardsService.create(board);    
        this.router.navigate(['/admin/boards']);        
      }

    ngOnInit() { } 

  }