import { Component, OnInit, OnDestroy, ViewChild } from '@angular/core';
import { ActivatedRoute} from '@angular/router';
import { Subscription } from 'rxjs';

import { MatTableDataSource } from '@angular/material/table';
import { MatDialogService } from 'src/app/services/mat-dialog.service';

import { Publisher } from 'src/app/model/publisher';
import { PublishersService } from 'src/app/services/publishers.service';

@Component({
    selector: 'app-publishers',
    templateUrl: './admin-publishers.component.html',
    styleUrls: []
  })
  export class AdminPublishersComponent implements  OnInit, OnDestroy { 
    publishers: Publisher[];
    subscription: Subscription;
    items: Publisher[] = [];
    itemCount: number;
    dude: any;
    id;

    listData: MatTableDataSource<any[]>;
    displayedColumns: string[] = ['publishername', 'edit', 'delete'];
    searchKey:string;

    constructor(private route: ActivatedRoute,
        private dialogService: MatDialogService,
        private publishersService:PublishersService) { 
          this.id = this.route.snapshot.paramMap.get('id');
    
          this.subscription = this.publishersService.getAll().subscribe(pbslist => {
            this.publishers = pbslist;
            console.log(this.publishers);
            });  
        }

        ngOnInit() {
            this.publishersService.getAll().subscribe(
              list=> {
                this.listData = new MatTableDataSource(list);
              //  this.listData.sort = this.sort;
              //  this.listData.paginator = this.paginator;
              }
            );
          }

          delete(key) {
            this.dialogService.openConfirmDialog('Are you sure to delete this record?')
            .afterClosed().subscribe(res => {
              if(res) {
                this.publishersService.delete(key);
              }
            }); 
          } 

    
    ngOnDestroy() {
      this.subscription.unsubscribe();
    }

  }