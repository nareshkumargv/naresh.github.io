import { Component, OnInit, OnDestroy, ViewChild } from '@angular/core';
import { ActivatedRoute} from '@angular/router';
import { Subscription } from 'rxjs';
import {Router} from "@angular/router";

import { MatTableDataSource } from '@angular/material/table';
import { MatDialogService } from 'src/app/services/mat-dialog.service';

import { Boards } from 'src/app/model/boards';
import { BoardsService } from 'src/app/services/boards.service';

@Component({
  selector: 'app-boards',
  templateUrl: './admin-boards.component.html',
  styleUrls: []
})
export class AdminBoardComponent implements  OnInit, OnDestroy {
  boards: Boards[];
  subscription: Subscription;
  items: Boards[] = [];
  itemCount: number;
  dude: any;
  id;

  listData: MatTableDataSource<any[]>;
  displayedColumns: string[] = ['boardname', 'edit', 'delete'];
  searchKey:string;

  constructor(private route: ActivatedRoute,private router:Router,
    private dialogService: MatDialogService,
    private boardsService:BoardsService) { 
      this.id = this.route.snapshot.paramMap.get('id');

      this.subscription = this.boardsService.getAll().subscribe(boards => {
        this.boards = boards;
        console.log(this.boards);
        });

    }

    ngOnInit() {
      this.boardsService.getAll().subscribe(
        list=> {
          this.listData = new MatTableDataSource(list);
        //  this.listData.sort = this.sort;
        //  this.listData.paginator = this.paginator;
        }
      );
    }

    delete(key) {
      this.dialogService.openConfirmDialog('Are you sure to delete this record?')
      .afterClosed().subscribe(res => {
        if(res) {
          this.boardsService.delete(key);
        }
      }); 
    } 

    navigateto() {
     this.router.navigate(['/admin/boards/new']);
    }

  ngOnDestroy() {
    this.subscription.unsubscribe();
   }


}