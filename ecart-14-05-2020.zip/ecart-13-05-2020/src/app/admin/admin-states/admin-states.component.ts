import { Component, OnInit, OnDestroy, ViewChild } from '@angular/core';
import { ActivatedRoute} from '@angular/router';
import { Subscription } from 'rxjs';

import { MatTableDataSource } from '@angular/material/table';
import { MatDialogService } from 'src/app/services/mat-dialog.service';

import { States } from 'src/app/model/states';
import { StatesService } from 'src/app/services/states.service';

@Component({
    selector: 'app-states',
    templateUrl: './admin-states.component.html',
    styleUrls: []
  })
  export class AdminStateComponent implements  OnInit, OnDestroy { 

    states: States[];
    subscription: Subscription;
    items: States[] = [];
    itemCount: number;
    dude: any;
    id;

    listData: MatTableDataSource<any[]>;
    displayedColumns: string[] = ['statename', 'edit', 'delete'];
    searchKey:string;

    constructor(private route: ActivatedRoute,
      private dialogService: MatDialogService,
      private statesService:StatesService) { 
        this.id = this.route.snapshot.paramMap.get('id');
  
        this.subscription = this.statesService.getAll().subscribe(states => {
          this.states = states;
          console.log(this.states);
          });  
      }

      ngOnInit() {
        this.statesService.getAll().subscribe(
          list=> {
            this.listData = new MatTableDataSource(list);
          //  this.listData.sort = this.sort;
          //  this.listData.paginator = this.paginator;
          }
        );
      }

      delete(key) {
        this.dialogService.openConfirmDialog('Are you sure to delete this record?')
        .afterClosed().subscribe(res => {
          if(res) {
            this.statesService.delete(key);
          }
        }); 
      } 

    ngOnDestroy() {
      this.subscription.unsubscribe();
     }

  }