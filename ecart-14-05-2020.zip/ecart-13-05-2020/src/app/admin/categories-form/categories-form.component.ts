import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { take } from 'rxjs/operators';

import { CategoriesService } from 'src/app/services/categories.service';

@Component({
    selector: 'app-categories-form',
    templateUrl: './categories-form.component.html',
    styleUrls: []
  })
  export class CategoriesFormComponent implements OnInit {
    category = {};
    id;

    constructor(
        private route: ActivatedRoute,private router: Router,
        private categoriesService: CategoriesService) {
          this.id = this.route.snapshot.paramMap.get('id');
          console.log("Category ID", this.id);
  
          // Important line of code to get single board from firebase
          if(this.id) this.categoriesService.get(this.id).valueChanges().
          pipe(take(1)).subscribe(p => this.category = p);
        }

        save(category) {
            console.log(category);
            if(this.id) this.categoriesService.update(this.id, category)
            else 
            this.categoriesService.create(category);    
            this.router.navigate(['/admin/categories']);        
        }

    ngOnInit() { } 
   }