import { Component, OnInit, OnDestroy, ViewChild } from '@angular/core';
import { ActivatedRoute} from '@angular/router';
import { Subscription } from 'rxjs';

import { MatTableDataSource } from '@angular/material/table';
import { MatDialogService } from 'src/app/services/mat-dialog.service';

import { ClassBooks } from 'src/app/model/classbooks';
import { ClassBooksService } from 'src/app/services/classbooks.service';

@Component({
    selector: 'app-admin-classbooks',
    templateUrl: './admin-classbooks.component.html',
    styleUrls: []
  })
  export class AdminClassBooksComponent implements OnInit, OnDestroy { 
    
    classbooks: ClassBooks[];
    subscription: Subscription;
    items: ClassBooks[] = [];
    itemCount: number;
    dude: any;
    id;

    listData: MatTableDataSource<any[]>;
    displayedColumns: string[] = ['title', 'price','cover', 'edit', 'delete'];
    searchKey:string;

    constructor(
        private route: ActivatedRoute,
        private dialogService: MatDialogService,
        private classbooksservice: ClassBooksService) {     
            this.id = this.route.snapshot.paramMap.get('id');

            this.subscription = this.classbooksservice.getAll().subscribe(cbooks => {
                this.classbooks = cbooks;
            });            
            }

            applyFilter() {
                this.listData.filter = this.searchKey.trim().toLowerCase();
              }

    
  onClear() {
    this.searchKey = "";
    this.applyFilter();
  }

  delete(key) {
    this.dialogService.openConfirmDialog('Are you sure to delete this record?')
    .afterClosed().subscribe(res => {
      if(res) {
        this.classbooksservice.delete(key);
      }
    }); 
  } 

  ngOnInit() {
    this.classbooksservice.getAll().subscribe(
      list=> {
        this.listData = new MatTableDataSource(list);
      //  this.listData.sort = this.sort;
      //  this.listData.paginator = this.paginator;
      }
    );
  }

    ngOnDestroy() {
        this.subscription.unsubscribe();
    }

  }