import { Component, OnInit, OnDestroy, ViewChild } from '@angular/core';
import { ActivatedRoute} from '@angular/router';
import { Subscription } from 'rxjs';

import { MatTableDataSource } from '@angular/material/table';
import { MatDialogService } from 'src/app/services/mat-dialog.service';

import { Class } from 'src/app/model/class';
import { ClassService } from 'src/app/services/class.service';

@Component({
    selector: 'app-class',
    templateUrl: './admin-class.component.html',
    styleUrls: []
  })
  export class AdminClassComponent implements  OnInit, OnDestroy {

    classes: Class[];
    subscription: Subscription;
    items: Class[] = [];
    itemCount: number;
    dude: any;
    id;

    listData: MatTableDataSource<any[]>;
    displayedColumns: string[] = ['classname', 'edit', 'delete'];
    searchKey:string;

    
    constructor(private route: ActivatedRoute,
        private dialogService: MatDialogService,
        private classService:ClassService) { 
          this.id = this.route.snapshot.paramMap.get('id');
    
          this.subscription = this.classService.getAll().subscribe(sclass => {
            this.classes = sclass;
            console.log(this.classes);
            });  
        }

    ngOnInit() {
        this.classService.getAll().subscribe(
          list=> {
            this.listData = new MatTableDataSource(list);
          //  this.listData.sort = this.sort;
          //  this.listData.paginator = this.paginator;
          }
        );
      }

      delete(key) {
        this.dialogService.openConfirmDialog('Are you sure to delete this record?')
        .afterClosed().subscribe(res => {
          if(res) {
            this.classService.delete(key);
          }
        }); 
      } 
  
      ngOnDestroy() {
        this.subscription.unsubscribe();
       }
    


    }