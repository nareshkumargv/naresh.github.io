import { Component, OnInit, OnDestroy, ViewChild } from '@angular/core';
import { ActivatedRoute} from '@angular/router';
import { Subscription } from 'rxjs';

import { MatTableDataSource } from '@angular/material/table';
import { MatDialogService } from 'src/app/services/mat-dialog.service';

import { School } from 'src/app/model/school';
import { SchoolService } from 'src/app/services/schools.service';

@Component({
  selector: 'app-admin-schools',
  templateUrl: './admin-schools.component.html',
  styleUrls: []
})
export class AdminSchoolsComponent implements OnInit {
  school: School[];
  subscription: Subscription;
  items: School[] = [];
  itemCount: number;
  dude: any;
  id;

  listData: MatTableDataSource<any[]>;
  displayedColumns: string[] = ['title','boardkey', 'edit', 'delete'];
  searchKey:string;

  
  constructor(private route: ActivatedRoute,
    private dialogService: MatDialogService,
    private schoolService:SchoolService) { 
      this.id = this.route.snapshot.paramMap.get('id');

      this.subscription = this.schoolService.getAll().subscribe(boards => {
        this.school = boards;
        console.log(this.school);
        });
    }

    ngOnInit() {
      this.schoolService.getAll().subscribe(
        list=> {
          this.listData = new MatTableDataSource(list);
        //  this.listData.sort = this.sort;
        //  this.listData.paginator = this.paginator;
        }
      );
    }

    delete(key) {
      this.dialogService.openConfirmDialog('Are you sure to delete this record?')
      .afterClosed().subscribe(res => {
        if(res) {
          this.schoolService.delete(key);
        }
      }); 
    } 

    ngOnDestroy() {
      this.subscription.unsubscribe();
     }

}