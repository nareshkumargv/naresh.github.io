import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { take } from 'rxjs/operators';
import { Subscription } from 'rxjs';
import { AngularFireStorage } from "@angular/fire/storage";
import { map, finalize } from "rxjs/operators";
import { Observable } from "rxjs";
import { FormGroup, FormControl, Validators } from '@angular/forms';

import { School } from 'src/app/model/school';
import { SchoolService } from 'src/app/services/schools.service';

import { Class } from 'src/app/model/class';
import { ClassService } from 'src/app/services/class.service';
import { Language } from 'src/app/model/languages';
import { LanguagesService } from 'src/app/services/language.service';
import { Category } from 'src/app/model/categories';
import { CategoriesService } from 'src/app/services/categories.service';
import { Publisher } from 'src/app/model/publisher';
import { PublishersService } from 'src/app/services/publishers.service';

import { ClassBooksService } from 'src/app/services/classbooks.service';

@Component({
    selector: 'app-classbooks-form',
    templateUrl: './classbooks-form.component.html',
    styleUrls: []
  })

  export class ClassBooksFormComponent implements OnInit {
    schools:School[];
    classes: Class[];
    languages: Language[];
    categories: Category[];
    publishers: Publisher[];
    
    subscription: Subscription;  
    classbook = {};
    id;
    //imgSrc: string;
    imgSrc = '../../../assets/images/logo/your-logo.png';
    selectedImage: any = null;
    isSubmitted: boolean;

    selectedFile: File = null;
    fb;
    downloadURL: Observable<string>;

    constructor(
      private storage: AngularFireStorage,
      private route: ActivatedRoute,
      private router: Router,        
      public schoolservice:SchoolService,
      public classservice:ClassService,
      public languagesService:LanguagesService,
      public categoriesService:CategoriesService,
      public publishersService:PublishersService,
      public classbookservice:ClassBooksService) { 

        this.id = this.route.snapshot.paramMap.get('id');
        //console.log("ClassBook ID", this.id);

           // Important line of code to get single product from firebase
    if(this.id) this.classbookservice.get(this.id).valueChanges().
    pipe(take(1)).subscribe(p => this.classbook = p);

  this.subscription = this.schoolservice.getAll().subscribe(sch => {
  this.schools = sch;
 // console.log(this.schools);
  });

  this.subscription = this.classservice.getAll().subscribe(sclass => {
  this.classes = sclass;
  //console.log(this.classes);
  });

  this.subscription = this.languagesService.getAll().subscribe(langs => {
  this.languages = langs;
  //console.log(this.languages);
  });

  this.subscription = this.categoriesService.getAll().subscribe(catgs => {
  this.categories = catgs;
  //console.log(this.categories);
  });

  this.subscription = this.publishersService.getAll().subscribe(pbslist => {
  this.publishers = pbslist;
  //console.log(this.publishers);
  }); 
      }

      // save(classbook) {
      //   console.log(classbook);
      //   if(this.id) this.classbookservice.update(this.id, classbook)
      //   else 
      //   this.classbookservice.create(classbook);    
      //   this.router.navigate(['/admin/classbooks']);        
      // }    

      showPreview(event: any) {
        if (event.target.files && event.target.files[0]) {
          const reader = new FileReader();
          reader.onload = (e: any) => this.imgSrc = e.target.result;
          reader.readAsDataURL(event.target.files[0]);
          this.selectedImage = (event.target.files[0]);
        }
        else {
          this.imgSrc = '../../../assets/images/logo/your-logo.png';
          this.selectedImage = null;
        }
      }


      save(classbook) {
        console.log(classbook);
        if(this.id) this.classbookservice.update(this.id, classbook)
        else 
        var filePath = `${'bookcovers'}/${this.selectedImage.name.split('.').slice(0, -1).join('.')}_${new Date().getTime()}`;
        const fileRef = this.storage.ref(filePath);

        this.storage.upload(filePath, this.selectedImage).snapshotChanges().pipe(
          finalize(() => {
            fileRef.getDownloadURL().subscribe((url) => {
              classbook['imageUrl'] = url;
              this.classbookservice.create(classbook);
              this.router.navigate(['/admin/classbooks']);
              //  this.resetForm();
            })
          })
        ).subscribe();

      //  this.classbookservice.create(classbook);    
      //  this.router.navigate(['/admin/classbooks']);        
      }  




    ngOnInit() { } 

}