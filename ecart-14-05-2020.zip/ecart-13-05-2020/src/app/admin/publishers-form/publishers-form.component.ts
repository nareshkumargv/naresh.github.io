import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { take } from 'rxjs/operators';

import { PublishersService } from 'src/app/services/publishers.service';

@Component({
    selector: 'app-publishers-form',
    templateUrl: './publishers-form.component.html',
    styleUrls: []
  })

  export class PublishersFormComponent implements OnInit {  
    publisher = {};
    id;

    constructor(
        private route: ActivatedRoute,private router: Router,
        private publishersService: PublishersService) {
          this.id = this.route.snapshot.paramMap.get('id');
          console.log("Publisher ID", this.id);
  
          // Important line of code to get single board from firebase
          if(this.id) this.publishersService.get(this.id).valueChanges().
          pipe(take(1)).subscribe(p => this.publisher = p);
        }

        save(publisher) {
            console.log(publisher);
            if(this.id) this.publishersService.update(this.id, publisher)
            else 
            this.publishersService.create(publisher);    
            this.router.navigate(['/admin/publishers']);        
        }    

    ngOnInit() { } 

  }