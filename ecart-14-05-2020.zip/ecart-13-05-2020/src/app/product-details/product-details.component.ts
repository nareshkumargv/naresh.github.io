import { Component, OnInit, Input } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { Subscription, Observable } from 'rxjs';

// import {Books} from 'src/app/model/books';
// import {BooksService } from 'src/app/services/books.service';

import { ClassBooks } from 'src/app/model/classbooks';
import { ClassBooksService } from 'src/app/services/classbooks.service';

import { ShoppingCartService } from 'src/app/services/shopping-cart.service';
import { ShoppingCart } from 'src/app/model/shopping-cart';

@Component({
    selector: 'app-product-details',
    templateUrl: './product-details.component.html',
    styleUrls: [],
    providers: [ClassBooksService]
  })
  export class ProductDetailsComponent implements OnInit {

    classbooks:ClassBooks[] = [];
    id;
    //books:Books[];
    bookslist:any;
    selectedbook:any;
    //books:any;
    subscription: Subscription;

   // filteredProducts: Books[] = [];
    filteredClassBooks: ClassBooks[] = [];
    cart$: Observable<ShoppingCart>;

  //  @Input('books') books: Books;
    @Input('classbook') classbook: ClassBooks;
    @Input('show-actions') showActions = true;
    @Input('shopping-cart') shoppingCart: ShoppingCart;  

    constructor(
        private route: ActivatedRoute,
        private router: Router,
       // private bookService:BooksService,
        private classbooksservice:ClassBooksService,
        private cartService: ShoppingCartService) {
        this.id = this.route.snapshot.paramMap.get('key');
           // console.log("book ID", this.id);
        }

        private populateBooks() { 
            // this.bookService.getAll().subscribe(books => {
            //   this.bookslist = books;
            //   console.log(this.bookslist);
            //     this.filteredProducts = this.bookslist.filter((bdata) => bdata.key == this.id);
            //     console.log(this.filteredProducts);
            // })

            this.classbooksservice.getAll().subscribe(books => {
                this.bookslist = books;
                console.log(this.bookslist);
                  this.filteredClassBooks = this.bookslist.filter((bdata) => bdata.key == this.id);
                  console.log(this.filteredClassBooks);
              })
        }

        addToCart() {    
           // console.log('add to cart');
           // console.log(this.books);
            this.cartService.addToCart(this.classbook);            
          } 

        async ngOnInit() {          
            this.populateBooks();
        }

     

   }