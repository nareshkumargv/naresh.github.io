import { Component, OnInit, Input, OnDestroy, AfterViewInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Subscription, Observable } from 'rxjs';

import {MatTabChangeEvent, VERSION} from '@angular/material';

import { Product } from 'src/app/model/product';
import { ProductService } from 'src/app/services/product.service';
import { PriceService } from 'src/app/services/price.service';

import {Books} from 'src/app/model/books';
import {BooksService } from 'src/app/services/books.service';
import { Category } from 'src/app/model/categories';
import { CategoriesService } from 'src/app/services/categories.service';

import { ClassBooks } from 'src/app/model/classbooks';
import { ClassBooksService } from 'src/app/services/classbooks.service';

import { ShoppingCart } from 'src/app/model/shopping-cart';
import { ShoppingCartService } from 'src/app/services/shopping-cart.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  
  version = VERSION;

  Images = ['../assets/images/bg/3.jpg'];  
  SlideOptions = { items: 1, dots: true, nav: true };  
  CarouselOptions = { items: 3, dots: true, nav: true };

  books:Books[] = [];
  classbooks:ClassBooks[] = [];
  categories: Category[];

  categories$;

  category:string; 
  gender: string;
  shape: string;
  price: number;
  bmake: string;
  band:string;
  dial:string;

  subscription: Subscription;
  searchKey: string;  
  currentPage: any;
  price$;

  activeTab = 0;
  activeLink:any;

  filteredProducts: Books[] = []; 
  filteredClassBooks: ClassBooks[] = []; 
  allbooks:ClassBooks[] = [];

  selectedTab: any;

  pageActual: number = 1;
  cart$: Observable<ShoppingCart>;

 // @Input('product') product: Product;
  @Input('book') book: Books;

  @Input('classbook') classbook: ClassBooks;
  @Input('show-actions') showActions = true;
  @Input('shopping-cart') shoppingCart: ShoppingCart;

  public selectedIndex: number = 0;

  constructor(
    private route: ActivatedRoute,
    // private productService: ProductService,
     private cartService: ShoppingCartService,
    // private priceService: PriceService,
    private categoriesService:CategoriesService,
    private bookService:BooksService,
    private classbooksservice:ClassBooksService) {
      this.subscription = this.categoriesService.getAll().subscribe(catgs => {
        this.categories = catgs;
      //  console.log(this.categories);
        //  this.activeLink = this.categories[0];
          //console.log(this.activeLink);
         // this.selectedTab = this.categories[0];
         // console.log(this.selectedTab);
        });        
   }

// private populateBooks() { 
// this.bookService.getAll().subscribe(books => {
//   this.filteredProducts = books;
//   console.log(this.filteredProducts);
// })
// }

private populateClassBooks() { 
  this.classbooksservice.getAll().subscribe(classbooks => {
    this.filteredClassBooks = classbooks;
 //   console.log(this.filteredClassBooks);
    this.allbooks = classbooks;
 //   console.log(this.allbooks);

  })
  }

  async ngOnInit() { 
    this.populateClassBooks(); 
  }

  onSequenceChangeEvent(event: MatTabChangeEvent) {
  //  console.log(event.tab.textLabel);
    this.selectedTab = event.tab.textLabel;
  //  console.log(this.selectedTab.key);

    if(this.selectedTab.key =="-M4YqC_jUit4M_fXNPpC"){
      //console.log('all');
      this.populateClassBooks(); 
    }
    else {
     // console.log('Academic');
      this.filteredClassBooks = this.allbooks.filter((classbooks) => classbooks.categorykey === this.selectedTab.key);
     // console.log(this.filteredClassBooks); 
    }

 

  }



  // addToCart() {
  //   console.log('cart');
  //  // this.cartService.addToCart(this.product); 
  // } 


//    private populateProducts() { 
    
//     this.productService.getAll().subscribe(products => {
//         this.products = products;      
//       this.route.queryParamMap.subscribe(params => {        
//           this.category = params.get('category');
//           this.applyFilterCategory();
//         if(params.get('gender') || this.gender) {
//           this.gender = params.get('gender');
//           this.applyFilterGender();
//         }
//         if(params.get('shape') || this.shape) {
//           this.shape = params.get('shape');
//           this.applyFilterShape();
//         } if(params.get('bmake') || this.bmake) {
//           this.bmake = params.get('bmake');
//           this.applyFilterBandMake();
//         }if(params.get('band') || this.band) {
//           this.band = params.get('band');
//           this.applyFilterBand();
//         }if(params.get('dial') || this.dial) {
//           this.dial = params.get('dial');
//           this.applyFilterDial();
//         }
//       });
//     }); 
//   } 

//     // For Category
//     private applyFilterCategory() { 
//       this.filteredProducts = (this.category) ? 
//         this.products.filter(p => p.categories === this.category) : 
//           this.products; 
//     }

//   // For Gender
//   private applyFilterGender() {
//     this.filteredProducts = (this.gender) ? 
//     this.products.filter(p => p.gender === this.gender) : 
//       this.products; 
//   }
//   // For Shape
//   private applyFilterShape(){
//     this.filteredProducts = (this.shape) ? 
//     this.products.filter(p => p.shape === this.shape) : 
//       this.products;
//   }

//   // For Band Make
//   applyFilterBandMake() {
//     this.filteredProducts = (this.bmake) ? 
//     this.products.filter(p => p.bmake === this.bmake) : 
//       this.products;
//   }

//   // For Band Color
//   applyFilterBand() {
//     this.filteredProducts = (this.band) ? 
//     this.products.filter(p => p.band === this.band) : 
//       this.products;
//   }

//   // For Dial Color
//   applyFilterDial() {
//     this.filteredProducts = (this.dial) ? 
//     this.products.filter(p => p.dial === this.dial) : 
//       this.products;
//   }

//     // For Search Query
//     filter(query: string) {
//       this.filteredProducts = (query) ? 
//       this.products.filter(p => p.title.toLowerCase().includes(query.toLowerCase()))
//       : this.products;
//     }
  
//     // For Clearing Search
//     onClear() {
//       let query: string;
//       this.searchKey = "";
//       this.filter(query);
//     }
  
//     ngOnDestroy() {
//       this.subscription.unsubscribe();
//     }


  
  //    onPageChange(page: number) {
  //     this.currentPage = page;
  //     window.scrollTo({top: 510, behavior: 'smooth'});
  //  }


//   ngOnInit() { 
// this.productService.getAll().subscribe(products => {
//   this.products = products;
//   console.log(this.products);
// })    
//   }

}
