import { Component, OnInit,AfterViewInit, OnDestroy, ViewChild } from '@angular/core';
import { ActivatedRoute} from '@angular/router';
import { Subscription } from 'rxjs';
import { forkJoin } from 'rxjs';

import { SchoolService } from 'src/app/services/schools.service';
import { StatesService } from 'src/app/services/states.service';
import { CitiesService } from 'src/app/services/cities.service';
import { BoardsService } from 'src/app/services/boards.service';

@Component({
  selector: 'app-schoolslist',
  templateUrl: './schoolslist.component.html',
  styleUrls: []
})
export class SchoolsListComponent implements OnInit {
  bid: any;
  sid: any;
  cid: any;
  public sub: any;

  Board: any = [];
  States:any = [];
  Cities:any = [];

  Schools:any = [];
  selectedschools:any=[];
  selectedcity:any;
  selectedstate:any;
  subscription: Subscription;  
  id;
  totschools:any;
  totlselectedschools:any;

  constructor(
    private route: ActivatedRoute,        
    public _schoolapi:SchoolService,
    private citiesService:CitiesService,
    private statesService:StatesService
    ) { 

      this.sub = this.route.params.subscribe(params => {
        this.bid = params['bid'];
        this.sid = params['sid'];
        this.cid = params['cid'];
        // console.log('Board Key:'+ this.bid);
        // console.log('State key:'+ this.sid);
        // console.log('City Key:'+ this.cid);
      });

        this.subscription = this._schoolapi.getAll().subscribe(sch => {
          this.Schools = sch;
          //console.log(this.Schools);
          //console.log(this.Schools.length);
          this.totschools = this.Schools.length;
          //console.log(this.totschools);

          this.selectedschools = this.Schools.filter((bdata) => bdata.boardkey === this.bid && bdata.statekey === this.sid && bdata.citykey === this.cid );
          //console.log(this.selectedschools.length);
          this.totlselectedschools = this.selectedschools.length;

        })

        this.subscription = this.citiesService.getAll().subscribe(cities => {
          this.Cities = cities;
          //console.log(this.Cities);
          this.selectedcity = this.Cities.filter((scity)=> scity.key == this.cid);
          //console.log(this.selectedcity);
        }); 

        this.subscription = this.statesService.getAll().subscribe(states => {
          this.States = states;
          //console.log(this.States);

          this.selectedstate = this.States.filter((sstate)=> sstate.key == this.sid);
          //console.log(this.selectedstate);
          });  
      }

      ngOnInit() { }
 
    }





  

