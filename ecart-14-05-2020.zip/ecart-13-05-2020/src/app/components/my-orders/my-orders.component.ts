import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { OrderService } from 'src/app/services/order.service';
import { AuthService } from 'src/app/services/auth.service';
import { switchMap } from 'rxjs/operators';

import { Order } from 'src/app/model/order';

@Component({
  selector: 'app-my-orders',
  templateUrl: './my-orders.component.html',
  styleUrls: ['./my-orders.component.scss']
})
export class MyOrdersComponent implements OnInit {

  orders:Order[] = [];
  orderlist:any;
  selectedorder: any[] = []; 
  group:any;

  order$: Observable<any[]>;

  constructor(private auth: AuthService,
    private orderService: OrderService) {
      var user = JSON.parse(localStorage.getItem("user"));
      console.log(user.uid);

      this.orderService.getAllOrders().subscribe(orders=> {
        this.orderlist= orders;
        console.log(this.orderlist);

        this.selectedorder = this.orderlist.filter((odata) => odata.userId == user.uid);
        console.log(this.selectedorder);
      })



     }

  ngOnInit() {
  //  this.order$ = this.auth.user$.pipe(switchMap(user => this.orderService.getOrderByUser(user.uid).valueChanges()));
 
//  this.orderService.getAllOrders().subscribe(orders=> {
// this.orderlist= orders;
// console.log(this.orderlist);

// this.order$ = this.orderlist.filter((orderdata) => orderdata.uid == user.uid);

//  }) 
 
  }
 
}
