import { Component, OnInit } from '@angular/core';
import { ActivatedRoute} from '@angular/router';
import {Router} from "@angular/router";
import { Subscription } from 'rxjs';

import { States } from 'src/app/model/states';
import { StatesService } from 'src/app/services/states.service';
import { Cities } from 'src/app/model/cities';
import { CitiesService } from 'src/app/services/cities.service';
import { Boards } from 'src/app/model/boards';
import { BoardsService } from 'src/app/services/boards.service';

import { SchoolService } from 'src/app/services/schools.service';

@Component({
  selector: 'app-academics',
  templateUrl: './Academics.component.html',
  styleUrls: []
})
export class AcademicsComponent implements OnInit {
  states: States[] = [];
  selectedstate: States[] = [];
  cities: Cities[];
  boards: Boards[];
  subscription: Subscription;

  selectedBoard:any;
  selectedState:any;
  selectedcity:any;
  filteredcity:any;   
  selstate:any;
  sskey:any;

  Schools:any = [];
  selectedschools:any=[];
  totschools:any;
  totlselectedschools:any;

  bid: any;
  sid: any;
  cid: any;
  public sub: any;

  showTab = 1;
  tabToggle(index){
    this.showTab =index;
  }

  constructor(
    private router:Router,
    private route: ActivatedRoute,
    private statesService:StatesService,
    private citiesService:CitiesService,
    private boardsService:BoardsService,
    public _schoolapi:SchoolService) {
      this.subscription = this.statesService.getAll().subscribe(states => {
        this.states = states;         
        });  

        this.subscription = this.citiesService.getAll().subscribe(cities => {
        this.cities = cities;        
        }); 

        this.subscription = this.boardsService.getAll().subscribe(boards => {
        this.boards = boards;      
        });

        this.subscription = this._schoolapi.getAll().subscribe(sch => {
        this.Schools = sch;        
        this.selectedschools = sch;
        this.totschools = this.Schools.length;
        this.totlselectedschools = this.Schools.length;       
        })
     }

    onSelectState() {  
      this.filteredcity = this.cities.filter((scity)=> scity.statekey == this.selectedState);     
    }

    search(bid: any,sid:any,cid:any) {  
      this.selectedschools = this.Schools.filter((bdata) => bdata.boardkey === bid && bdata.statekey === sid && bdata.citykey === cid );
      this.totlselectedschools = this.selectedschools.length;    
      this.selectedcity = this.cities.filter((scity)=> scity.key === cid);    
      this.selectedstate = this.states.filter((sstate)=>sstate.key == sid);    
    }

  ngOnInit() {}

}
