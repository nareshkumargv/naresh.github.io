import { Component, OnInit } from '@angular/core';
import { ActivatedRoute} from '@angular/router';
import {Router} from "@angular/router";
import { Subscription } from 'rxjs';

import { States } from 'src/app/model/states';
import { StatesService } from 'src/app/services/states.service';

import { Cities } from 'src/app/model/cities';
import { CitiesService } from 'src/app/services/cities.service';
import { Boards } from 'src/app/model/boards';
import { BoardsService } from 'src/app/services/boards.service';


@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: []
})
export class SearchComponent implements OnInit {

  states: States[];
  cities: Cities[];
  boards: Boards[];
  subscription: Subscription;

  selectedBoard:any;
  selectedState:any;
  selectedcity:any;

  constructor(
    private router:Router,
    private route: ActivatedRoute,
    private statesService:StatesService,
    private citiesService:CitiesService,
    private boardsService:BoardsService) {

        this.subscription = this.statesService.getAll().subscribe(states => {
        this.states = states;
       // console.log(this.states);
        });  

        this.subscription = this.citiesService.getAll().subscribe(cities => {
        this.cities = cities;
       // console.log(this.cities);
        }); 

        this.subscription = this.boardsService.getAll().subscribe(boards => {
        this.boards = boards;
       // console.log(this.boards);
        });
     }

     onSelectState() {
        console.log(this.selectedState);
        this.selectedcity = this.cities.filter((scity)=> scity.statekey == this.selectedState);
       // console.log(this.selectedcity);
    }

    search(bid: any,sid:any,cid:any) {
        // console.log('clicked');
        // console.log('board'+ bid);
        // console.log('State'+ sid);
        // console.log('City'+cid);
        this.router.navigate(['/schoolslist', bid, sid, cid]);
       //this.router.navigate(['/schoolslist']);
    }

  ngOnInit() {
  }

}
