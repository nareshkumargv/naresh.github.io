import { Component, OnInit } from '@angular/core';
import { AuthService } from "../../services/auth.service";

@Component({
  selector: 'app-popup-login',
  templateUrl: './popup-login.component.html',
  styleUrls: []
})
export class PopupLoginComponent implements OnInit {

  constructor(public authService: AuthService) { }

  ngOnInit() {
  }

}
