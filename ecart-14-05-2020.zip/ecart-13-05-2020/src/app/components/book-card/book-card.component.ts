import { Component, OnInit, Input } from '@angular/core';
import { ShoppingCartService } from 'src/app/services/shopping-cart.service';
import { ShoppingCart } from 'src/app/model/shopping-cart';

import { ClassBooks } from 'src/app/model/classbooks';

@Component({
    selector: 'book-card',
    templateUrl: './book-card.component.html',
    styleUrls: ['./book-card.component.css']
  })
  export class BookCardComponent implements OnInit { 
    @Input('classbooks') classbooks: ClassBooks;
    @Input('show-actions') showActions = true;
    @Input('shopping-cart') shoppingCart: ShoppingCart;

    constructor(private cartService: ShoppingCartService) { }

  addToCart() {    
    console.log('add to cart');
    this.cartService.addToCart(this.classbooks); 
    console.log(this.classbooks);
  } 

  ngOnInit() {
  }

  }