import { Component, OnInit,Output,EventEmitter,Input } from '@angular/core'; 
import { Router, ActivatedRoute } from '@angular/router';
import { Subscription, Observable } from 'rxjs';
import { MatOptionSelectionChange } from '@angular/material';

import { StatesService } from 'src/app/services/states.service';
import { CitiesService } from 'src/app/services/cities.service';
import { BoardsService } from 'src/app/services/boards.service';

import { SchoolService } from 'src/app/services/schools.service';
import { ClassService } from 'src/app/services/class.service';
import { LanguagesService } from 'src/app/services/language.service';

import { ClassBooks } from 'src/app/model/classbooks';
import { ClassBooksService } from 'src/app/services/classbooks.service';

import { ShoppingCart } from 'src/app/model/shopping-cart';
import { ShoppingCartService } from 'src/app/services/shopping-cart.service';

@Component({
    selector: 'app-schoolsdetails',
    templateUrl: './school-details.component.html',
    styleUrls: []
  })
  export class SchoolsDetailsComponent implements OnInit {  

    id;
    schoolid:any;
    cityid:any;
    stateid:any;
    public sub: any;

    Schools:any = [];
    selectedschools:any=[];
    selectedcity:any;
    selectedstate:any;

    Classes:any = [];
    selectedclass:any;

    Languages:any = [];
    selectedlanguage:any;

    subscription: Subscription;  

    classbooks:ClassBooks[] = [];
    books: ClassBooks[] = []; 
    filteredClassBooks: ClassBooks[] = []; 
    Cities:any = [];
    States:any = [];
    totalbooks:any = [];
    totalfilteredbooks:any = [];

    @Input('classbook') classbook: ClassBooks;
    @Input('show-actions') showActions = true;
    @Input('shopping-cart') shoppingCart: ShoppingCart;

    constructor(
        private route: ActivatedRoute,
        private router: Router,
        private _schoolapi:SchoolService,
        private _classapi:ClassService,
        private _languagesapi:LanguagesService,
        private classbooksservice:ClassBooksService,
        private cartService: ShoppingCartService,
        private citiesService:CitiesService,
        private statesService:StatesService
       ) {
        // this.id = this.route.snapshot.paramMap.get('key');
        // console.log("School ID", this.id);

        this.sub = this.route.params.subscribe(params => {
            this.schoolid = params['key'];
            this.cityid = params['cid'];
            this.stateid = params['sid'];              
        });

        this.subscription = this._schoolapi.getAll().subscribe(sch => {
            this.Schools = sch;
        //    console.log(this.Schools);        
  
            this.selectedschools = this.Schools.filter((bdata) => bdata.key === this.schoolid);
        //    console.log(this.selectedschools);           
           
        })

        this.subscription = this._classapi.getAll().subscribe(sclass => {
            this.Classes = sclass;
        //    console.log(this.Classes);
        }); 

        this.subscription = this._languagesapi.getAll().subscribe(langs => {
            this.Languages = langs;
        //    console.log(this.Languages);
        });

        this.subscription = this.citiesService.getAll().subscribe(cities => {
            this.Cities = cities;
        //    console.log(this.Cities);
            this.selectedcity = this.Cities.filter((scity)=> scity.key === this.cityid);
        //    console.log(this.selectedcity);
        }); 
  
        this.subscription = this.statesService.getAll().subscribe(states => {
            this.States = states;
        //    console.log(this.States);
  
            this.selectedstate = this.States.filter((sstate)=> sstate.key == this.stateid);
        //    console.log(this.selectedstate);
            });  
        }

        public async selected(event: MatOptionSelectionChange, id: string): Promise<void> {
            this._classapi.onCustomerSelect.next(id);
        }

        public async languageselected(event: MatOptionSelectionChange, id: string): Promise<void> {
            this._languagesapi.onCustomerSelect.next(id);
        }

        

        private populateClassBooks() {          
            // this.classbooksservice.getAll().subscribe(classbooks => {
            //   this.filteredClassBooks = classbooks;
            //   console.log(this.filteredClassBooks);
            // })
        }
          
        async ngOnInit() {
         //   this.populateClassBooks();      
        }

        search(cid: any, lid:any) {        
            console.log('class'+ cid);
            console.log('language'+ lid); 
            console.log("School ID", this.schoolid);   
            
            this.classbooksservice.getAll().subscribe(classbooks => {
            this.books = classbooks;
          //  console.log(this.books);
            this.totalbooks = this.books.length;
          //  console.log(this.totalbooks);

            this.filteredClassBooks = this.books.filter((bdata) => bdata.schoolkey === this.schoolid && bdata.classkey === cid && bdata.languagekey === lid);
          //  console.log(this.filteredClassBooks);
            this.totalfilteredbooks = this.filteredClassBooks.length;
            })

            
        }

        clearCart() {
            this.cartService.clearCart();
        }

       

   }