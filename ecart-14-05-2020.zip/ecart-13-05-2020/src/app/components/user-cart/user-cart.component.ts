
import { Component, OnInit, ElementRef, QueryList, ViewChild, ViewChildren, AfterViewInit, Renderer2 } from '@angular/core';
//import {Inject, ElementRef as ErrorProneElementRef} from '@angular/core';

import { ActivatedRoute} from '@angular/router';
import {Router} from "@angular/router";
import { Subscription, Observable } from 'rxjs';

import { ShoppingCartService } from 'src/app/services/shopping-cart.service';
import { ShoppingCart } from 'src/app/model/shopping-cart';
import { LanguagesService } from 'src/app/services/language.service';
import { ClassService } from 'src/app/services/class.service';

@Component({
  selector: 'user-cart',
  templateUrl: './user-cart.component.html',
  styleUrls: ['./user-cart.component.scss']
})
export class UserCartComponent implements OnInit  { 
 
  schoolid:any;
  public sub: any;
  Languages:any = [];
  selectedlanguage:any; 
  public shipping = 500;

  Classes:any = [];
  selectedclass:any;
  userselclass:any = [];

  subscription: Subscription;  
  cart$:Observable<ShoppingCart>;

    constructor(
      private router:Router,
      private route: ActivatedRoute,
      private _classapi:ClassService,
      private _languagesapi:LanguagesService,
      private cartService: ShoppingCartService,
      private el:ElementRef,
      private renderer: Renderer2) {         
        this.sub = this.route.params.subscribe(params => {
            this.schoolid = params['key'];                 
        });

        this.subscription = this._classapi.getAll().subscribe(sclass => {
            this.Classes = sclass;
          //  console.log(this.Classes);
        }); 

        this.subscription = this._languagesapi.getAll().subscribe(langs => {
            this.Languages = langs;
          //  console.log(this.Languages);
        });

      }
  
    public async ngOnInit() {      
      this.cart$ = await this.cartService.getCart();
      //console.log(this.cart$);

      this._classapi.onCustomerSelect.subscribe(value => {
      //  console.log('FROM Display Comp -----', value);
        this.selectedclass = value;
      //  console.log(this.selectedclass);

        if (this.selectedclass) { 
        this._classapi.get(this.selectedclass).then(Response => {
        //    console.log(Response);            
          })
        }

        // if (this.selectedclass) { 
        //   this.userselclass = this._classapi.get(this.selectedclass).set(Response => {
        //       console.log(Response);            
        //     })
        //   }
      })

      this._languagesapi.onCustomerSelect.subscribe(value => {
      //  console.log('FROM Display Comp -----', value);
        this.selectedlanguage = value;
      //  console.log(this.selectedlanguage);

        if (this.selectedlanguage) { 
          this._languagesapi.get(this.selectedlanguage).then(Response => {
              console.log(Response);            
            })
          }
      })   

    }

    clearCart() {
      this.cartService.clearCart();
    }

    checkout(schoolid:any,sname:any,sno:any,selectedclass:any,selectedlanguage:any,gtotal:any) {
      // console.log('School Key:'+ schoolid); 
      // console.log('Student Name:'+ sname);
      // console.log('Student Admission:'+ sno);        
      // console.log('Class Key:'+ selectedclass);
      // console.log('Language Key:'+ selectedlanguage);
      // console.log('Grand Total:'+ gtotal);
      this.router.navigate(['components/check-out', schoolid,sname,sno,selectedclass,selectedlanguage,gtotal]);
    }




}