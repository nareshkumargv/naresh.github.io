import { Component, OnInit } from '@angular/core';
import { AngularFireStorage } from "@angular/fire/storage";
import { map, finalize } from "rxjs/operators";
import { Observable } from "rxjs";
import { FormGroup, FormControl, Validators } from '@angular/forms';
//import { url } from 'inspector';

import { ImageService } from '../../services/image.service';

@Component({
  selector: 'app-imageupload',
  templateUrl: './image-upload.component.html',
  styleUrls: []
})
export class ImageUploadComponent implements OnInit {
  FormValue = {};  
  imgSrc: string;
  selectedImage: any = null;
  isSubmitted:boolean;

    formTemplate = new FormGroup({
      caption: new FormControl('',Validators.required),
      category: new FormControl(''),
      imageUrl: new FormControl('',Validators.required),
    })

    constructor(
      private storage: AngularFireStorage, 
      private imageservice:ImageService) {}

  ngOnInit() {
    this.resetForm();
  }

showPreview(event:any) {
  if(event.target.files && event.target.files[0]){
    const reader = new FileReader();
    reader.onload = (e:any) => this.imgSrc = e.target.result;
    reader.readAsDataURL(event.target.files[0]);
    this.selectedImage = (event.target.files[0]);
  }
  else {
    this.imgSrc = './assets/images/logo/your-logo.png';
    this.selectedImage = null;
  }
}

onSubmit(FormValue) {
console.log(FormValue);
this.isSubmitted = true;
  if(this.formTemplate.valid) {
  var filePath = `${FormValue.category}/${this.selectedImage.name.split('.').slice(0,-1).join('.')}_${new Date().getTime()}`;
  const fileRef = this.storage.ref(filePath);
  this.storage.upload(filePath,this.selectedImage).snapshotChanges().pipe(
    finalize(()=>{
      fileRef.getDownloadURL().subscribe((url)=>{
        FormValue['imageUrl']=url;
        this.imageservice.create(FormValue);
        this.resetForm();
      })
    })
  ).subscribe();
  }
}

// onSubmit(FormValue) {
//   console.log(FormValue);
//   this.imageservice.create(FormValue);
// }

get formControls() {
  return this.formTemplate['controls'];
}

resetForm() {
  this.formTemplate.reset();
  this.formTemplate.setValue({
    caption:'',
    imageUrl:'',
    category:'School'
  });
  this.imgSrc = './assets/images/logo/your-logo.png';
  this.selectedImage = null;
  this.isSubmitted=false;
}

  




}