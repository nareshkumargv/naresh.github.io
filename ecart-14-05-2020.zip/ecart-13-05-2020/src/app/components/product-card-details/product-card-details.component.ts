import { Component, OnInit, Input } from '@angular/core';
import { ShoppingCartService } from 'src/app/services/shopping-cart.service';
import { ShoppingCart } from 'src/app/model/shopping-cart';

import { Books } from 'src/app/model/books';

@Component({
  selector: 'product-card-details',
  templateUrl: './product-card-details.component.html',
  styleUrls: []
})
export class ProductCardDetailsComponent implements OnInit {
   @Input('books') books: Books;
   @Input('show-actions') showActions = true;
   @Input('shopping-cart') shoppingCart: ShoppingCart;
  
  constructor(private cartService: ShoppingCartService) { }

  addToCart() {    
    console.log('add to cart');
    this.cartService.addToCart(this.books); 
    console.log(this.books);
  } 

  ngOnInit() {
  }

}
