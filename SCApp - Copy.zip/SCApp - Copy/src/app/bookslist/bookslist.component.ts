import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Routes } from '@angular/router';
import { forkJoin } from 'rxjs';

import { ClassBooks } from '../models/classbooks';
import { ClassBooksApiService } from '../services/classbooks-api.service';

import { DataShareService } from '../services/data-share.service';
import { LocalStorageService } from '../services/local-storage.service';

import { DataToCart } from '../models/data-to-cart';

@Component({
    selector: 'app-bookslist',
    templateUrl: './bookslist.component.html',
    styleUrls: [],
    providers:[ClassBooksApiService,DataShareService,LocalStorageService]
})

export class BooksListComponent {
    page:string;
    classbooksdetails;
    cart:any[];
    cartLength:number;    
    emittedItem:any[];    
    storageName:string;

    constructor(private route: ActivatedRoute, private activatedRoute: ActivatedRoute,
        public _classbooksapi:ClassBooksApiService,
        private _dataShareService:DataShareService,
        private _localStorageService:LocalStorageService,
    ) {}
   
    ngOnInit() {
    this.page  = "shop";
    this.cartLength = 0    
    this.cart = [];
    this.storageName = "cartCleared";
    this.getData();

        return forkJoin([
            this._classbooksapi.getClassBooks()
        ])
        .subscribe((data:any[]) => {
            this.classbooksdetails = data[0];
            console.log(this.classbooksdetails);
         })
    }

    getData() {
        this._classbooksapi.getClassBooks().subscribe(
            data => {return this.classbooksdetails = data},
            err => console.error(err),
            () => console.log('done loading books')
         );
    }

    addToCart(i:number):void{
        var bookToCart = new DataToCart().setData(this.classbooksdetails,i);
        var cartStatus = this._localStorageService.getLocalstorage(this.classbooksdetails, this.storageName);
        //Check if cart is cleared
        if(cartStatus === 1){
            this.cart = [];
            this._localStorageService.setLocalstorage(0, this.storageName);
            this.cart.push(bookToCart);
            console.log(this.cart);
          }else{
            this.cart = this.cart;
            this.cart.push(bookToCart);
            console.log(this.cart);
          }
    }

    passData(cart:any[]):void{
        this.cart = cart;
        this._dataShareService.sendData(this.cart);
    }



}