import { Component, OnInit } from '@angular/core';
import {Router} from "@angular/router";
import { trigger,state,style,transition,animate } from '@angular/animations';
import { forkJoin } from 'rxjs';

import { BoardsApiService } from "../services/boards-api.service";
import { StatesApiService } from "../services/states-api.service";
import { CitiesApiService } from "../services/cities-api.service";
import { SchoolsApiService } from "../services/schools-api.service";

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css'],
  animations: [
    trigger('rowExpansionTrigger', [
        state('void', style({
            transform: 'translateX(-10%)',
            opacity: 0
        })),
        state('active', style({
            transform: 'translateX(0)',
            opacity: 1
        })),
        transition('* <=> *', animate('400ms cubic-bezier(0.86, 0, 0.07, 1)'))
    ])
],
  providers:[]
})
export class HomeComponent {
  
  Board: any = [];
  States:any = [];
  Cities:any = [];
  Schools:any = [];

  boardsservicedata:any = [];
  statesservicedata:any = [];
  citiesservicedata:any = [];
  schoolsservicedata:any = [];

  selectedcity:any;
  seclectedschool:any;

constructor(private router:Router, 
  public _boardapi:BoardsApiService, 
  public _statesapi:StatesApiService,
  public _citiesapi:CitiesApiService,
  public _schoolsapi:SchoolsApiService
) {}

ngOnInit() {
 // this.getboardslist();
//  this.getstates();
  //this.getcities(); 

  // return this._citiesapi.getCities().subscribe((data: {}) => {
  //   this.Cities = data;
  //   console.log(this.Cities);
  // })

  // return this._schoolsapi.getSchools().subscribe((sdata:{})=> {
  //   this.Schools = sdata;
  //   console.log(this.Schools);
  // })

  return forkJoin([
    this._boardapi.getBoards(),
    this._statesapi.getStates(),
    this._citiesapi.getCities(),
    this._schoolsapi.getSchools()
  ])
  .subscribe((data:any[]) => {
    this.Board = data[0];
    console.log(this.Board);

    this.States = data[1];
    console.log(this.States);

    this.Cities = data[2];
    console.log(this.Cities);

    this.Schools = data[3];
    console.log(this.Schools);
  })
}

onSelectState(event) {
  console.log(event.value.id);
  this.selectedcity = this.Cities.filter((scity)=> scity.sid == event.value.id);
  console.log(this.selectedcity);
}

// onSelectCity(event) {
// //console.log(event.value.id);
// this.seclectedschool = this.Schools.filter((sch) => sch.cid == event.value.id);
// console.log(this.seclectedschool);
// }

search(bid: any, sid: any, cid: any) {
  console.log('vid-' + bid);
  console.log('cid-' + sid);
  console.log('lid-' + cid);
  this.router.navigate(['/schlists', bid, sid, cid]);
}

handleClick(bid,sid,cid) {
  console.log(bid,sid,cid);
  this.seclectedschool = this.Schools.filter((sch) => sch.bid == bid && sch.sid == sid && sch.cid == cid);
  console.log(this.seclectedschool);

}

}
