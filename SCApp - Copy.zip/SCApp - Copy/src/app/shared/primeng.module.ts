import { NgModule } from '@angular/core';

import { TableModule } from 'primeng/table';
import { PaginatorModule } from 'primeng/paginator';
import { PanelModule } from 'primeng/panel';
import { DialogModule } from 'primeng/dialog';
import { CheckboxModule } from 'primeng/checkbox';
import { ButtonModule } from 'primeng/button';
import { OverlayPanelModule } from 'primeng/overlaypanel';
import {AccordionModule} from 'primeng/accordion';
import {TriStateCheckboxModule} from 'primeng/components/tristatecheckbox/tristatecheckbox';
import {GrowlModule} from 'primeng/components/growl/growl';
import {TabViewModule} from 'primeng/tabview';
import {CalendarModule} from 'primeng/calendar';

import {ListboxModule} from 'primeng/listbox';

@NgModule({
    exports: [TableModule, 
        PaginatorModule, PanelModule, DialogModule, CheckboxModule,TriStateCheckboxModule,GrowlModule, ButtonModule, 
        OverlayPanelModule,AccordionModule,TabViewModule,CalendarModule,ListboxModule]
})
export class PrimeNGModule { }