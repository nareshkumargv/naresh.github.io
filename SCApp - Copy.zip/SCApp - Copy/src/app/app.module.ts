import { BrowserModule } from '@angular/platform-browser';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
import { ReactiveFormsModule } from '@angular/forms';
import { FormsModule } from '@angular/forms';
import { PrimeNGModule } from './shared/primeng.module';

import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { footerComponent } from './footer/footer.component';
import { HomeComponent } from './home/home.component';

import { BooksListComponent } from './bookslist/bookslist.component';
import { SchlistsComponent } from './schlists/schlists.component';
import { SchDetailsComponent } from './schdetails/schdetails.component';
import { CartComponent } from './cart/cart.component';

import { ContactComponent } from './contact/contact.component';
import { ProductComponent } from './product/product.component';

@NgModule({
  declarations: [
    AppComponent,HeaderComponent,footerComponent,HomeComponent,
    SchlistsComponent,SchDetailsComponent,CartComponent,ProductComponent,
    ContactComponent,BooksListComponent
  ],
  imports: [
    BrowserModule,BrowserAnimationsModule,HttpClientModule,PrimeNGModule,ReactiveFormsModule,FormsModule,
    RouterModule.forRoot([
      { path: '', component: HomeComponent, pathMatch: 'full'},       
      //{ path: 'schlists', component: SchlistsComponent},
      { path: 'schlists/:bid/:sid/:cid', component: SchlistsComponent},
      { path: 'schdetails/:id', component: SchDetailsComponent},       
      { path: 'bookslist', component: BooksListComponent},
      { path: 'contact', component: ContactComponent},
      
      { path: 'product', component: ProductComponent},
      { path: 'cart', component: CartComponent},
      { path: '**', redirectTo: '' }

    ])
  ],
  providers: [HttpClientModule],
  bootstrap: [AppComponent]
})
export class AppModule { }
