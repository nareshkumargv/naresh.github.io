import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Routes } from '@angular/router';
import { forkJoin } from 'rxjs';

import { FormGroup, FormControl } from '@angular/forms';

import { SchoolDetails } from '../models/schooldetails';
import { SchDetailsApiService } from "../services/schdetails-api.service";

import { Classes } from '../models/classes';
import { ClassesApiService } from '../services/classes-api.service';

import { ClassBooks } from '../models/classbooks';
import { ClassBooksApiService } from '../services/classbooks-api.service';

import { Language } from '../models/language';
import { LanguageApiService } from '../services/language-api.service';
import { element } from '@angular/core/src/render3';

@Component({
    selector: 'app-schdetails',
    templateUrl: './schdetails.component.html',
    styleUrls: [],
    providers:[]
})

export class SchDetailsComponent {
    public sid:any;
    public sub: any;

    private total: number = 0;

    schdetails: SchoolDetails[] = [];
    schdetailsdata:any = [];

    classdetails: Classes[] = [];
    classesdata:any = [];

    classbooksdetails: ClassBooks[] =[];
    classbooksdata:any =[];

    languagedetails: Language[] = [];
    languagedata:any = [];
    languagedatalist:any =[];

    masterSelected:boolean;
    checklist:any;
    checkedList:any;
    lngcheckedList:any;
    cartTotal:number;
    totalitems:number;

    filter:any;

    constructor(private route: ActivatedRoute, private activatedRoute: ActivatedRoute,
        public _schdetailsapi:SchDetailsApiService,
        public _classesdetailsapi:ClassesApiService,
        public _classbooksapi:ClassBooksApiService,
        public _languageapi:LanguageApiService
    ) {}

    ngOnInit() {
        this.sub = this.route.params.subscribe(params => {
            this.sid = params['id'];
        //    console.log(this.sid);
          });

        return forkJoin([
            this._schdetailsapi.getSchoolsDetails(),
            this._classesdetailsapi.getClasses(),
            this._classbooksapi.getClassBooks(),
            this._languageapi.getLanguages()
        ])
        .subscribe((data:any[]) => {
            this.schdetails = data[0];
            this.classdetails = data[1];
            this.classbooksdetails = data[2];
            this.languagedetails = data[3];
            // console.log(this.schdetails);
            // console.log(this.classdetails);
            // console.log(this.classbooksdetails);
            // console.log(this.languagedetails);

            this.schdetailsdata = this.schdetails.filter((rdata) => rdata.sid == this.sid);
            console.log(this.schdetailsdata);

            this.classesdata = this.classdetails.filter((cdata) => cdata.sid == this.sid);
            console.log(this.classesdata);

            this.languagedata = this.languagedetails.filter((ldata) => ldata.sid == this.sid);
            console.log(this.languagedata);

            this.filter = this.classbooksdetails;
            console.log(this.filter);
        })
    }

    onSelectClass(event) {
        console.log(event.value.id);
        this.languagedatalist = this.languagedata.filter((ldata) => ldata.classid == event.value.id);
        console.log(this.languagedatalist);
    }

    onlanguageSelect() {
    this.lngcheckedList = [];
    for (var i = 0; i < this.languagedatalist.length; i++) {
        if(this.languagedatalist[i].isSelected)
        this.lngcheckedList.push(this.languagedatalist[i]);
        console.log(this.lngcheckedList);
    }
        this.classbooksdata = [];
        this.classbooksdetails.forEach((cbooks,i) => {
            this.lngcheckedList.forEach((selectedLang,i) => {
                if(selectedLang.id == cbooks.language) {
                    //console.log(cbooks);
                    this.classbooksdata.push(cbooks);
                    console.log(this.classbooksdata);
                }
            });
        });
        console.log(this.classbooksdata);
    }

    checkUncheckAll() {
        for (var i = 0; i < this.classbooksdata.length; i++) {
          this.classbooksdata[i].isSelected = this.masterSelected;
        }
        this.getCheckedItemList();
    }

    // checkUncheckAll() {
    //     this.filter.forEach((element, index) => {
    //         element.isSelected = this.masterSelected;
    //         this.classbooksdata.push(this.filter[index]);
    //     });
    //     this.getCheckedItemList();
    // }

    isAllSelected() {
        this.getCheckedItemList();
    }

    getCheckedItemList(){
         this.total = 0;
         this.checkedList = [];

        for (var i = 0; i < this.classbooksdata.length; i++) {
          if(this.classbooksdata[i].isSelected)
           this.checkedList.push(this.classbooksdata[i]);
           console.log(this.checkedList);
        // this.checkedList.push({
        //     id:this.classbooksdata[i].id,
        //     bookname:this.classbooksdata[i].bookname,
        //     bookprice:this.classbooksdata[i].bookprice
        // })
        }
        this.totalitems = this.checkedList.length;
        this.doTotal();
    }

    // deletebook(id: number): void {
    //     console.log(id);
    //     this.checkedList = this.checkedList.filter((item) => item.id !== id);
    //     console.log(this.checkedList);

    //     let idx = this.classbooksdata.findIndex(element => element.id == id);

    //     if (idx > -1) {
    //         this.classbooksdata[idx].isAllSelected = false;
    //     }
    //     this.isAllSelected();
    // }

    doTotal() {
        if(!this.checkedList.length) {
            this.cartTotal = 0;
        } else {
            const add = (a:number, b:number) => a + b;
            let booksArray:Array<any> = this.checkedList.sort();
            let itemPriceArray:Array<any> = [];
            for (let k in booksArray){
                itemPriceArray.push(Number(booksArray[k].bookprice));
            }
            this.cartTotal = itemPriceArray.reduce(add);
        }
        return this.cartTotal;
    }




    ngOnDestroy() {
        this.sub.unsubscribe();
    }




 }

