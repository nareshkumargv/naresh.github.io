export class SchoolDetails {
    id: number;
    bid:number;
    sid:number;
    cid:number;    
    sname: string;
    logo:string;
    desc:string;
} 