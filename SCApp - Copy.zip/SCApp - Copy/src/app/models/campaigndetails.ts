export interface CampaignDetails {
    campaignid:number,  
    segment:string;
    type:string;
    groupcode:string;
    rate:string;  
    amount:string;
  }