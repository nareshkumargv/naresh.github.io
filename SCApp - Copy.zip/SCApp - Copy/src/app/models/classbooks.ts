export class ClassBooks {
    id: number;
    sid:number;
    classid:number;
    bookname: string;
    bookimage: string;
    bookprice:string;
    publishername:string;
    language:number;
    category:number;
 } 