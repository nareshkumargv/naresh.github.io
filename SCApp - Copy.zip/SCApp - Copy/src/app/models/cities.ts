export class Cities {
    id: number;
    sid:number;
    name: string;   
} 