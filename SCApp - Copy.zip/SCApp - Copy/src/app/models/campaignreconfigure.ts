export interface CampaignReconfigure {
    campaignid:number,
    jobnumber:number;
    cusip:number;
    companyname:string;
    segment:string;
    type:string;
    groupcode:string;
    jobstatus:string;  
    maildate:string;
    meetingdate:string;
    recorddate:string;    
  }