export interface Invoice {
    invid:string,  
    invtype:string;
    invamt:string;          
  }