export class States {
    id: number;
    name: string;   
 } 