import { Product } from '../models/product';

export class Item {
    product: Product;
    quantity: number;

}