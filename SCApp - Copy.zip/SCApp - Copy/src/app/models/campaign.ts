export interface Campaign {
    campaignid:number,  
    companyname:string;
    cusip:string;
    totalamt:string;
    status:string;  
  }