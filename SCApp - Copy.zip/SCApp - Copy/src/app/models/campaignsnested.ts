export interface CampaignsNested {
    campaignid:number,  
    segment:string;
    type:string;
    groupcode:string;
    jobnumber:string;
    quantity:string;
    rate:string;  
    amount:string;
    itemname:string;
  }