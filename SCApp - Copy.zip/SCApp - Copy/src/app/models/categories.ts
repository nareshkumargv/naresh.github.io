export class Categories {
    id: number;    
    categoryname: string;    
}