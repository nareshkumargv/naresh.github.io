export class Boards {
    id: number;
    name: string;   
 } 