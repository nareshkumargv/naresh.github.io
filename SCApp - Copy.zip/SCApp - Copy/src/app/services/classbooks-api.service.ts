import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { retry, catchError } from 'rxjs/operators';

import { ClassBooks } from '../models/classbooks';

@Injectable({
    providedIn: 'root'
  })
  
export class ClassBooksApiService {

  apiURL = 'http://localhost:3000';
  constructor(private http: HttpClient) { }
  
  // Http Options
  httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      })
    } 

    getClassBooks(): Observable<ClassBooks> {
        return this.http.get<ClassBooks>(this.apiURL + '/classbooks')
        .pipe(
          retry(1),
          catchError(this.handleError)
        )
    }
    
    find(id: string): ClassBooks {
        return this.getClassBooks[this.getSelectedIndex(id)];
    }

    private getSelectedIndex(id: string) {
      for (var i = 0; i < this.getClassBooks.length; i++) {
          if (this.getClassBooks[i].id == id) {
              return i;
          }
      }
      return -1;
  }
    
        // Error handling 
        handleError(error) {
            let errorMessage = '';
            if(error.error instanceof ErrorEvent) {
              // Get client-side error
              errorMessage = error.error.message;
            } else {
              // Get server-side error
              errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
            }
            window.alert(errorMessage);
            return throwError(errorMessage);
         }  



}