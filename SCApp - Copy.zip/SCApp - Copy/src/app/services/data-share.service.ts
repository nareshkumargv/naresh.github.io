import { Injectable } from '@angular/core';
import { Subject } from 'rxjs'; 
 
@Injectable()
export class DataShareService {
    shareDataSubject = new Subject<any>(); 
    
    sendData(data){
      this.shareDataSubject.next(data);      
    }

}
