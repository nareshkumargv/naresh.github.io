import { Component, OnInit,AfterViewInit } from '@angular/core';
import { ActivatedRoute, Routes } from '@angular/router';
import { forkJoin } from 'rxjs';

import { BoardsApiService } from "../services/boards-api.service";
import { StatesApiService } from "../services/states-api.service";
import { CitiesApiService } from "../services/cities-api.service";
import { SchoolsApiService } from "../services/schools-api.service";

@Component({
    selector: 'app-schlists',
    templateUrl: './schlists.component.html',
    styleUrls: [],
    providers:[]
})

export class SchlistsComponent implements OnInit {
    bid: any;
    sid: any;
    cid: any;
    public sub: any;

    Board: any = [];
    States:any = [];
    Cities:any = [];
    Schools:any = [];
    selectedschools:any=[];

    constructor(private route: ActivatedRoute,
        public _boardapi:BoardsApiService, 
        public _statesapi:StatesApiService,
        public _citiesapi:CitiesApiService,      
        public _schoolsapi:SchoolsApiService
    ) {}

      ngOnInit() {
        this.sub = this.route.params.subscribe(params => {
            this.bid = params['bid'];
            this.sid = params['sid'];
            this.cid = params['cid'];
            console.log(this.bid,this.sid,this.cid);
          });

          return forkJoin([
            this._boardapi.getBoards(),
            this._statesapi.getStates(),
            this._citiesapi.getCities(),
            this._schoolsapi.getSchools()            
          ])
          .subscribe((data:any[]) => {
            this.Board = data[0];
            this.States = data[1];
            this.Cities = data[2];
            this.Schools = data[3];
            // console.log(this.Board);
            // console.log(this.States);
            // console.log(this.Cities);
            // console.log(this.Schools);

            for (var i = 0; i < this.Schools.length; i++) {
                if (this.Schools[i].bid == this.bid && this.Schools[i].sid == this.sid && this.Schools[i].cid == this.cid) {
                  this.selectedschools.push(this.Schools[i]);
                  console.log(this.selectedschools);
                }
            }


          })
        
       }  

    


 }