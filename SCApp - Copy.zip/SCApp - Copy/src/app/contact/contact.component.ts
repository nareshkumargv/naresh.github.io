
import { Component } from '@angular/core';
import { FormGroup, FormArray, FormControl, FormBuilder} from '@angular/forms';
import { Pipe, PipeTransform } from '@angular/core';

@Component({
    selector: 'app-contact',
    templateUrl: './contact.component.html',
    styleUrls: ['./contact.component.css'],
    providers:[]
})

export class ContactComponent {
  name = 'Angular 5';
  
  categories: Group[] = [];
  selectedCategories: Group[] = [];

  constructor() {
    this.categories = [
      {name :"Group 1", id: 1},
      {name :"Group 2", id: 2},
      {name :"Group 3", id: 3},
      {name :"Group 4", id: 4},
      {name :"Group 5", id: 5},
      {name :"Group 6", id: 6},
      {name :"Group 7", id: 7},
      {name :"Group 8", id: 8},
      {name :"Group 9", id: 9},
      {name :"Group 10", id: 10},
      {name :"Group 11", id: 11},
      {name :"Group 12", id: 12},
      {name :"Group 13", id: 13},
      {name :"Group 14", id: 14},
      {name :"Group 15", id: 15}      
  ];
  }

  // onSelect(sg): void {    
  //   this.selectedGroup = sg;
  //   console.log(this.selectedGroup);    
  // }

  deleteItem(id:number):void {
    alert(id);
    this.selectedCategories = this.selectedCategories.filter((item) => item.id !== id);
    console.log(this.selectedCategories);
    
  }


}

export interface Group {  
  name:string;
  id:number;  
}